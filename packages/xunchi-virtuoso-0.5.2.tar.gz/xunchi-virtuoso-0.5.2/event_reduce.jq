# Only render assistant text. Reasoning text is intentionally never copied out.
def text_answer: [.order[] as $id | .parts[$id] | select(.type=="text" and .role=="assistant") | .text] | join("\n");
foreach inputs as $raw
 ({parts:{},order:[],roles:{},phase:"waiting",revision:0,last_emit:0};
  ($raw.payload // $raw) as $event |
  ($event.properties // {}) as $p |
  .changed=false |
  if $event.type=="message.updated" and $p.info.sessionID==$sid then
    .roles[$p.info.id]=$p.info.role |
    .parts |= with_entries(if .value.message==$p.info.id then .value.role=$p.info.role else . end)
  elif $event.type=="message.part.updated" and $p.part.sessionID==$sid then
    $p.part as $part |
    if $part.type=="text" and .roles[$part.messageID]=="assistant" then
      if .parts[$part.id]==null then .order += [$part.id] else . end |
      .parts[$part.id]={type:"text",role:(.roles[$part.messageID] // "unknown"),message:$part.messageID,text:($part.text // "")} |
      .phase="answering" | .changed=true
    elif $part.type=="reasoning" then .phase="thinking" | .changed=true
    elif $part.type=="tool" then
      .phase=(if $part.state.status=="running" then "tool" else "thinking" end) | .changed=true
    else . end
  elif $event.type=="message.part.delta" and $p.sessionID==$sid and $p.field=="text" and .parts[$p.partID].type=="text" then
    .parts[$p.partID].text += $p.delta | .phase="answering" | .changed=true
  else . end |
  if .changed then .revision+=1 else . end |
  .emit=(.changed and ((now-.last_emit)>=0.08 or .last_phase!=.phase)) |
  if .emit then .last_emit=now | .last_phase=.phase else . end;
  if .emit then {request_id:$request_id,phase:.phase,answer:text_answer,revision:.revision,time:now} else empty end)

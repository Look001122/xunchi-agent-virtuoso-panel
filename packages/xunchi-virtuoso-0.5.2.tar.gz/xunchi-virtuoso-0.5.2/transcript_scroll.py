# -*- coding: utf-8 -*-
"""Explicit follow/history mode; layout changes never count as user scrolling."""
from __future__ import unicode_literals
from gi.repository import Gtk, Gdk, GLib


class TranscriptScroll(object):
    def __init__(self, view, scrolled, changed=None):
        self.view = view
        self.buffer = view.get_buffer()
        self.adjustment = scrolled.get_vadjustment()
        self.follow = True
        self.generation = 0
        self.source = 0
        self.user_source = 0
        self.anchor = None
        self.dragging = False
        self.changed = changed
        self.adjustment.connect('changed', self.bounds_changed)
        scrolled.connect('scroll-event', self.wheel)
        view.connect('scroll-event', self.wheel)
        view.connect('key-press-event', self.key)
        view.connect('button-press-event', self.reading)
        scrollbar = scrolled.get_vscrollbar()
        scrollbar.connect('button-press-event', self.drag_start)
        scrollbar.connect('button-release-event', self.drag_end)

    def set_follow(self, value):
        self.follow = bool(value)
        self.generation += 1
        if self.changed:
            self.changed(self.follow)

    def at_bottom(self):
        return self.adjustment.get_value() + self.adjustment.get_page_size() >= self.adjustment.get_upper() - 24

    def reading(self, widget, event):
        if event.button == 1:
            self.set_follow(False)
        return False

    def wheel(self, widget, event):
        self.set_follow(False)
        self.check_user_position()
        return False

    def key(self, widget, event):
        if event.keyval in (Gdk.KEY_Up, Gdk.KEY_Down, Gdk.KEY_Page_Up, Gdk.KEY_Page_Down, Gdk.KEY_Home, Gdk.KEY_End):
            self.set_follow(False)
            self.check_user_position()
        return False

    def drag_start(self, widget, event):
        self.dragging = True
        self.set_follow(False)
        return False

    def drag_end(self, widget, event):
        self.dragging = False
        self.check_user_position()
        return False

    def check_user_position(self):
        if self.user_source:
            GLib.source_remove(self.user_source)
        def finish():
            self.user_source = 0
            if not self.dragging and self.at_bottom():
                self.set_follow(True)
                self.schedule()
            return False
        self.user_source = GLib.timeout_add(40, finish)

    def bounds_changed(self, *unused):
        if self.follow and not self.dragging:
            self.schedule()

    def clear_anchor(self):
        if self.anchor is not None:
            self.buffer.delete_mark(self.anchor)
            self.anchor = None

    def before_update(self):
        self.clear_anchor()
        if not self.follow and not self.dragging:
            rectangle = self.view.get_visible_rect()
            result = self.view.get_iter_at_location(rectangle.x, rectangle.y)
            iterator = result[-1] if isinstance(result, tuple) else result
            self.anchor = self.buffer.create_mark(None, iterator, True)
            self.anchor_delta = self.adjustment.get_value() - self.view.get_iter_location(iterator).y

    def after_update(self, changed):
        if changed:
            self.schedule()
        else:
            self.clear_anchor()

    def latest(self):
        self.clear_anchor()
        self.set_follow(True)
        self.schedule()
        return False

    def schedule(self):
        if self.source:
            GLib.source_remove(self.source)
        generation = self.generation
        def settle():
            self.source = 0
            if self.dragging or generation != self.generation:
                self.clear_anchor()
                return False
            if self.follow:
                # Force pending text layout before reading the final bounds.
                self.view.get_iter_location(self.buffer.get_end_iter())
                self.adjustment.set_value(max(self.adjustment.get_lower(),
                    self.adjustment.get_upper() - self.adjustment.get_page_size()))
            elif self.anchor is not None:
                iterator = self.buffer.get_iter_at_mark(self.anchor)
                value = self.view.get_iter_location(iterator).y + self.anchor_delta
                self.adjustment.set_value(max(self.adjustment.get_lower(), min(value,
                    self.adjustment.get_upper() - self.adjustment.get_page_size())))
            self.clear_anchor()
            return False
        self.source = GLib.idle_add(settle, priority=GLib.PRIORITY_LOW)

    def snapshot(self):
        rectangle = self.view.get_visible_rect()
        result = self.view.get_iter_at_location(rectangle.x, rectangle.y)
        iterator = result[-1] if isinstance(result, tuple) else result
        return {'follow': self.follow, 'value': self.adjustment.get_value(), 'visible_offset': iterator.get_offset(),
                'upper': self.adjustment.get_upper(), 'page_size': self.adjustment.get_page_size()}

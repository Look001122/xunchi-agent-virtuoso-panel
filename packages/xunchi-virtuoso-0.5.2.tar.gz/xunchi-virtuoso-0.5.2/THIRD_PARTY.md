# jq runtime dependency

- Upstream: https://github.com/jqlang/jq
- Release: jq-1.8.1
- Asset: https://github.com/jqlang/jq/releases/download/jq-1.8.1/jq-linux-amd64
- SHA256: `020468de7539ce70ef1bceaf7cde2e8c4f2ca6c3afb84642aabc5c97d9fc2a0d`
- Checksum matched GitHub's published release asset digest.
- This official static x86-64 binary was executed successfully on this CentOS7 host.
- jq license and incorporated code notices: `JQ_COPYING`.
- Oniguruma license: `ONIGURUMA_COPYING`.

The dependency is local to the plugin; no system package or global jq executable is replaced.

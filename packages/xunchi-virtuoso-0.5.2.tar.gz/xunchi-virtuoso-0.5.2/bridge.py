"""Menu-launched X11 host discovery and Unicode UI supervisor; Python 2.7+."""
from __future__ import print_function
import argparse
import io
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from x11 import X11

ROOT = os.path.dirname(os.path.abspath(__file__))


def write(path, data):
    text = json.dumps(data, ensure_ascii=True, indent=2)
    if isinstance(text, bytes):
        text = text.decode('ascii')
    with io.open(path, 'w', encoding='utf-8') as stream:
        stream.write(text)


def emit(text):
    print(text)
    sys.stdout.flush()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pid', type=int, required=True)
    parser.add_argument('--resume', help='Reuse an existing idle panel directory and native host')
    args = parser.parse_args()
    owner_pid = os.getppid()
    base = os.path.expanduser('~/.local/state/xunchi-virtuoso')
    if not os.path.isdir(base):
        try:
            os.makedirs(base, 0o700)
        except OSError:
            if not os.path.isdir(base):
                raise
    folder = os.path.abspath(args.resume) if args.resume else tempfile.mkdtemp(prefix='session-{}-'.format(args.pid), dir=base)
    child = None
    x = X11()

    def terminate(signum, frame):
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    try:
        if args.resume:
            with io.open(os.path.join(folder, 'launch.json'), encoding='utf-8') as stream:
                previous = json.load(stream)
            host = previous['host_xid']
            if previous['pid'] != args.pid or str(host) not in x.snapshot(args.pid):
                raise RuntimeError('Resume host does not belong to this Virtuoso process')
            emit('XC_RESUME ' + folder)
        else:
            baseline = x.snapshot(args.pid)
            if not baseline:
                raise RuntimeError('No X11 windows belonging to the launching Virtuoso')
            write(os.path.join(folder, 'baseline_x11.json'), baseline)
            emit('XC_RUN ' + folder)
            ready = os.path.join(folder, 'host.ready')
            deadline = time.time() + 15
            while not os.path.isfile(ready):
                if time.time() > deadline or not os.path.exists('/proc/{}'.format(args.pid)):
                    raise RuntimeError('Timed out waiting for native dock creation')
                time.sleep(.1)
            candidates = []
            for unused in range(30):
                nodes = x.snapshot(args.pid)
                candidates = [node for key, node in nodes.items() if key not in baseline
                              and node['width'] > 100 and node['height'] > 100 and node['map_state'] == 2]
                if len(candidates) == 1:
                    break
                time.sleep(.2)
            write(os.path.join(folder, 'host_candidates.json'), candidates)
            if len(candidates) != 1:
                raise RuntimeError('Native host is not unique ({} candidates)'.format(len(candidates)))
            host = candidates[0]['id']
        env = os.environ.copy()
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        gui_command = [sys.executable, '-B', os.path.join(ROOT, 'chat.py'), '--host', str(host), '--run', folder]
        local_test = env.get('XUNCHI_VIRTUOSO_TEST_LOCAL_ECHO') == '1'
        if local_test:
            gui_command.append('--local-echo')
        with open(os.path.join(folder, 'chat.log'), 'a') as log, open(os.devnull) as null:
            child = subprocess.Popen(gui_command,
                                     env=env, stdin=null, stdout=log, stderr=subprocess.STDOUT)
        write(os.path.join(folder, 'launch.json'),
              {'pid': args.pid, 'chat_pid': child.pid, 'bridge_pid': os.getpid(),
                'host_xid': host, 'run': folder, 'version': '0.5.0',
                'mode': 'local_echo_no_llm' if local_test else 'agent_design'})

        deadline = time.time() + 12
        while True:
            try:
                with io.open(os.path.join(folder, 'ui_state.json'), encoding='utf-8') as stream:
                    current_state = json.load(stream)
                if current_state.get('pid') == child.pid:
                    break
            except (IOError, ValueError):
                pass
            if child.poll() is not None or time.time() > deadline:
                raise RuntimeError('Unicode UI failed to become ready; inspect chat.log')
            time.sleep(.1)
        emit('XC_READY')
        while child.poll() is None:
            if not os.path.exists('/proc/{}'.format(args.pid)) or not os.path.exists('/proc/{}'.format(owner_pid)):
                return
            time.sleep(.25)
        if child.returncode:
            raise RuntimeError('Unicode UI exited with {}'.format(child.returncode))
    except Exception as error:
        write(os.path.join(folder, 'error.json'), {'error': str(error)})
        emit('XC_ERROR ' + str(error))
        raise SystemExit(1)
    finally:
        if child is not None and child.poll() is None:
            child.terminate()
            for unused in range(20):
                if child.poll() is not None:
                    break
                time.sleep(.1)
            if child.poll() is None:
                child.kill()
            child.wait()
        x.close()


if __name__ == '__main__':
    main()

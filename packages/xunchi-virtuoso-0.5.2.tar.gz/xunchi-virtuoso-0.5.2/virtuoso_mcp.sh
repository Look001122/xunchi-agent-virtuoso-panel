#!/bin/bash
# MCP framing in Bash/jq; the actual design query runs only in SKILL.
set -uo pipefail
source "$(dirname -- "$0")/shell_common.sh"
[[ ${1:-} == --run && -d ${2:-} ]] || exit 2
run=$2

query_live() {
    local operation=${1:-get_design_context} arguments=${2:-\{\}}
    local ident token turn_id selection response i attempts temp
    if [[ ! -f "$run/active_turn.json" ]]; then
        printf '{"ok":false,"error":{"code":"NO_ACTIVE_TARGET"}}\n'
        return
    fi
    token=$("$JQ" -r '.target_token // empty' "$run/active_turn.json")
    turn_id=$("$JQ" -r '.request_id // empty' "$run/active_turn.json")
    selection=$("$JQ" -r '.selection_token // ""' "$run/active_turn.json")
    if [[ "$operation" == execute_skill && -f "$run/execution_cursor.json" ]]; then
        if "$JQ" -e --arg id "$turn_id" --arg token "$token" '.request_id==$id and .target_token==$token' "$run/execution_cursor.json" >/dev/null; then
            selection=$("$JQ" -r .selection_token "$run/execution_cursor.json")
        fi
    fi
    if [[ -z "$token" || "$token" == *$'\n'* || "$token" == *$'\r'* ]]; then
        printf '{"ok":false,"error":{"code":"INVALID_TARGET"}}\n'
        return
    fi
    if [[ -e "$run/tool.request" || -e "$run/tool.executing" ]]; then
        printf '{"ok":false,"error":{"code":"TOOL_BUSY"}}\n'
        return
    fi
    ident=$(uuid_hex)
    response="$run/tool-response-$ident.json"
    if [[ "$operation" == execute_skill ]]; then
        "$JQ" -r '.code' <<<"$arguments" >"$run/skill-code-$ident.il"
    fi
    printf '%s\n%s\n%s\n%s\n%s\n' "$ident" "$operation" "$token" "$selection" "$turn_id" >"$run/tool-request-$ident.tmp"
    mv -- "$run/tool-request-$ident.tmp" "$run/tool.request"
    jwrite "$run/tool_progress.json" -nc --arg id "$turn_id" --arg tool "$ident" --arg operation "$operation" \
        '{request_id:$id,tool_call_id:$tool,operation:$operation,state:"running"}'
    attempts=240
    [[ "$operation" == execute_skill ]] && attempts=5800
    for ((i=0; i<attempts; i++)); do
        [[ -f "$response" ]] && break
        sleep .05
    done
    if [[ ! -f "$response" ]]; then
        printf '{"ok":false,"error":{"code":"VIRTUOSO_TIMEOUT","message":"Live SKILL process did not respond; execution outcome may be unknown. Inspect state before retrying."}}\n'
        return
    fi
    if ! "$JQ" -e --arg id "$ident" --slurpfile launch "$run/launch.json" \
        '(.ok != true) or (.request_id==$id and .virtuoso_pid==$launch[0].pid)' "$response" >/dev/null; then
        printf '{"ok":false,"error":{"code":"RESPONSE_MISMATCH"}}\n'
        return
    fi
    if [[ "$operation" == execute_skill ]] && "$JQ" -e '.ok==true and .executed==true' "$response" >/dev/null; then
        jwrite "$run/execution_cursor.json" -c --arg id "$turn_id" '{request_id:$id,target_token,selection_token:.selection_after_token}' "$response"
    fi
    if [[ "$operation" == get_design_context ]]; then
        temp="$response.annotated"
        "$JQ" -c --slurpfile turn "$run/active_turn.json" '.+{send_snapshot:$turn[0].request_snapshot,
          selection_matches_send:(.selection_token==$turn[0].selection_token)}' "$response" >"$temp"
        mv -f -- "$temp" "$response"
    fi
    "$JQ" -nc --arg id "$turn_id" --arg tool "$ident" --arg operation "$operation" --slurpfile result "$response" \
        '{request_id:$id,tool_call_id:$tool,tool:$operation,time:now,result:$result[0]}' >>"$run/tool_calls.jsonl"
    jwrite "$run/tool_progress.json" -nc --arg id "$turn_id" --arg tool "$ident" --arg operation "$operation" \
        '{request_id:$id,tool_call_id:$tool,operation:$operation,state:"completed"}'
    "$JQ" -c . "$response"
}

if [[ ${3:-} == --capture ]]; then
    query_live capture_context
    exit
fi

while IFS= read -r message; do
    if ! "$JQ" -e 'type=="object" and has("id")' <<<"$message" >/dev/null 2>&1; then
        continue
    fi
    id=$("$JQ" -c .id <<<"$message")
    method=$("$JQ" -r '.method // ""' <<<"$message")
    case "$method" in
        initialize)
            result=$("$JQ" -c '{protocolVersion:(.params.protocolVersion // "2024-11-05"),
                capabilities:{tools:{}},serverInfo:{name:"xunchi-virtuoso-design",version:"0.5.1"}}' <<<"$message") ;;
        ping) result='{}' ;;
        tools/list) result=$("$JQ" -nc --slurpfile tool "$ROOT/tool-schema.json" --slurpfile execute "$ROOT/execute-skill-schema.json" '{tools:($tool+$execute)}') ;;
        tools/call)
            if "$JQ" -e '.params.name=="get_design_context" and
                ((.params.arguments // {}) | type=="object" and length==0)' <<<"$message" >/dev/null; then
                value=$(query_live)
            elif "$JQ" -e '.params.name=="execute_skill" and (.params.arguments|type=="object") and
                ((.params.arguments|keys)==["code"]) and (.params.arguments.code|type=="string" and length>0 and utf8bytelength<=262144)' <<<"$message" >/dev/null; then
                arguments=$("$JQ" -c .params.arguments <<<"$message")
                value=$(query_live execute_skill "$arguments")
            else
                value='{"ok":false,"error":{"code":"UNSUPPORTED_TOOL_OR_ARGUMENTS"}}'
            fi
            result=$("$JQ" -c '{content:[{type:"text",text:(.|tojson)}],isError:(.ok!=true)}' <<<"$value") ;;
        *) "$JQ" -nc --argjson id "$id" '{jsonrpc:"2.0",id:$id,error:{code:-32601,message:"Method not found"}}'; continue ;;
    esac
    "$JQ" -c --argjson id "$id" '{jsonrpc:"2.0",id:$id,result:.}' <<<"$result"
done

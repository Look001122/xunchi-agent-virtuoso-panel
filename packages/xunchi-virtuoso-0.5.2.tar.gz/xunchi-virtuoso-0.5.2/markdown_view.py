# -*- coding: utf-8 -*-
"""Small native Gtk Markdown view; model content is text, never executable HTML."""
from __future__ import unicode_literals
import re
import unicodedata
from operation_view import selection_text, operation_lines

INLINE = re.compile(r'(`[^`\n]+`|\*\*.+?\*\*|__.+?__|\[[^\]]+\]\([^\)]+\)|(?<!\*)\*[^*\n]+\*(?!\*))')


def plain(text):
    def replace(match):
        token = match.group(0)
        if token.startswith('['):
            return token[1:token.index(']')]
        return token[2:-2] if token.startswith(('**', '__')) else token[1:-1]
    return INLINE.sub(replace, text)


def cells(line):
    return [cell.strip().replace('\\|', '|') for cell in re.split(r'(?<!\\)\|', line.strip().strip('|'))]


def blocks(text):
    lines = text.splitlines()
    result = []
    i = 0
    while i < len(lines):
        line = lines[i]
        fence = re.match(r'^\s*(```+|~~~+)\s*(.*)$', line)
        if fence:
            marker, language = fence.groups()
            content = []
            i += 1
            while i < len(lines) and not re.match(r'^\s*' + re.escape(marker[0]) + r'{3,}\s*$', lines[i]):
                content.append(lines[i])
                i += 1
            result.append(('code', language, '\n'.join(content)))
            i += 1
            continue
        if i + 1 < len(lines) and '|' in line and re.match(r'^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$', lines[i + 1]):
            rows = [cells(line)]
            i += 2
            while i < len(lines) and '|' in lines[i] and lines[i].strip():
                rows.append(cells(lines[i]))
                i += 1
            result.append(('table', rows))
            continue
        heading = re.match(r'^(#{1,6})\s+(.+?)\s*#*$', line)
        if heading:
            result.append(('heading', len(heading.group(1)), heading.group(2)))
        elif re.match(r'^\s*([-*_])(?:\s*\1){2,}\s*$', line):
            result.append(('rule',))
        elif re.match(r'^\s*[-+*]\s+', line):
            result.append(('list', re.sub(r'^\s*[-+*]\s+', '• ', line)))
        elif line.startswith('>'):
            result.append(('quote', line.lstrip('> ').strip()))
        else:
            result.append(('paragraph', line))
        i += 1
    return result


def width(text):
    return sum(0 if unicodedata.combining(char) else 2 if unicodedata.east_asian_width(char) in ('W', 'F') else 1 for char in text)


def table_lines(rows):
    columns = max(len(row) for row in rows)
    rows = [[plain(cell) for cell in row] + [''] * (columns - len(row)) for row in rows]
    widths = [min(32, max(width(row[col]) for row in rows)) for col in range(columns)]
    def split(text, limit):
        chunks, part = [], ''
        for char in text:
            if part and width(part + char) > limit:
                chunks.append(part)
                part = ''
            part += char
        return chunks + [part]
    def border(left, middle, right):
        return left + middle.join('─' * (size + 2) for size in widths) + right
    output = [border('┌', '┬', '┐')]
    for index, row in enumerate(rows):
        chunks = [split(cell, widths[col]) for col, cell in enumerate(row)]
        for n in range(max(len(chunk) for chunk in chunks)):
            values = [chunk[n] if n < len(chunk) else '' for chunk in chunks]
            output.append('│ ' + ' │ '.join(value + ' ' * (widths[col] - width(value)) for col, value in enumerate(values)) + ' │')
        if index == 0:
            output.append(border('├', '┼', '┤'))
    output.append(border('└', '┴', '┘'))
    return '\n'.join(output) + '\n'


class MarkdownRenderer(object):
    def __init__(self, view):
        from gi.repository import Gtk, Pango
        self.view = view
        self.buffer = view.get_buffer()
        styles = {
            'body': {'foreground': '#243447', 'pixels_below_lines': 3},
            'user': {'foreground': '#203d61', 'background': '#edf4fc', 'pixels_above_lines': 5, 'pixels_below_lines': 5},
            'role': {'weight': Pango.Weight.BOLD, 'foreground': '#3060a0', 'pixels_above_lines': 14, 'pixels_below_lines': 6},
            'meta': {'foreground': '#69788a', 'scale': .87},
            'bold': {'weight': Pango.Weight.BOLD},
            'italic': {'style': Pango.Style.ITALIC},
            'inline': {'family': 'monospace', 'background': '#edf1f5'},
            'code': {'family': 'monospace', 'background': '#f0f3f7', 'left_margin': 10, 'right_margin': 8, 'wrap_mode': Gtk.WrapMode.NONE},
            'table': {'family': 'monospace', 'foreground': '#33465d', 'wrap_mode': Gtk.WrapMode.NONE},
            'quote': {'foreground': '#69788a', 'left_margin': 16},
            'heading': {'weight': Pango.Weight.BOLD, 'scale': 1.16, 'pixels_above_lines': 8},
            'link': {'foreground': '#245da1', 'underline': Pango.Underline.SINGLE}}
        self.tags = {name: self.buffer.create_tag('xc_' + name, **properties) for name, properties in styles.items()}
        self.codes = []
        self.stats = {}
        self._plan = []
        initial = self.buffer.get_text(self.buffer.get_start_iter(), self.buffer.get_end_iter(), True)
        self._text = initial.decode('utf-8') if isinstance(initial, bytes) else initial
        self._recording = None
        self.last_update = {'kind': 'none', 'preserved_prefix': 0, 'removed': 0, 'inserted': 0}

    def insert(self, text, *tags):
        if not text:
            return
        if self._recording is not None:
            self._recording.append((text, tuple(tags)))
        else:
            self.buffer.insert_with_tags(self.buffer.get_end_iter(), text, *[self.tags[name] for name in tags])

    def apply_plan(self, plan):
        if plan == self._plan:
            self.last_update = {'kind': 'none', 'preserved_prefix': len(self._text), 'removed': 0, 'inserted': 0}
            return False
        new_text = ''.join(text for text, tags in plan)
        old_text = self._text
        style_start = 0
        for previous, current in zip(self._plan, plan):
            if previous != current:
                break
            style_start += len(current[0])
        prefix = min(style_start, len(old_text), len(new_text))
        limit = min(len(old_text), len(new_text))
        while prefix < limit and old_text[prefix] == new_text[prefix]:
            prefix += 1
        suffix = 0
        while (suffix < len(old_text) - prefix and suffix < len(new_text) - prefix
               and old_text[len(old_text) - suffix - 1] == new_text[len(new_text) - suffix - 1]):
            suffix += 1
        removed = len(old_text) - prefix - suffix
        added = new_text[prefix:len(new_text) - suffix if suffix else len(new_text)]
        self.buffer.begin_user_action()
        try:
            if removed:
                self.buffer.delete(self.buffer.get_iter_at_offset(prefix),
                                   self.buffer.get_iter_at_offset(len(old_text) - suffix))
            if added:
                self.buffer.insert(self.buffer.get_iter_at_offset(prefix), added)
            # Only restyle the changed suffix; completed history keeps its tags,
            # marks, selection and layout instead of being cleared on every token.
            style_start = min(style_start, prefix)
            self.buffer.remove_all_tags(self.buffer.get_iter_at_offset(style_start), self.buffer.get_end_iter())
            offset = 0
            for text, names in plan:
                end = offset + len(text)
                if end > style_start:
                    start_iter = self.buffer.get_iter_at_offset(max(offset, style_start))
                    end_iter = self.buffer.get_iter_at_offset(end)
                    for name in names:
                        self.buffer.apply_tag(self.tags[name], start_iter, end_iter)
                offset = end
        finally:
            self.buffer.end_user_action()
        self._plan, self._text = list(plan), new_text
        self.last_update = {'kind': 'splice' if removed or added else 'style',
                            'preserved_prefix': prefix, 'removed': removed, 'inserted': len(added)}
        return True

    def inline(self, text, base='body'):
        offset = 0
        for match in INLINE.finditer(text):
            self.insert(text[offset:match.start()], base)
            token = match.group(0)
            kind = 'inline' if token.startswith('`') else 'bold' if token.startswith(('**', '__')) else 'link' if token.startswith('[') else 'italic'
            self.insert(plain(token), base, kind)
            self.stats[kind] = self.stats.get(kind, 0) + 1
            offset = match.end()
        self.insert(text[offset:], base)

    def markdown(self, text):
        for block in blocks(text):
            kind = block[0]
            self.stats[kind] = self.stats.get(kind, 0) + 1
            if kind == 'code':
                self.insert('代码' + (' · ' + block[1] if block[1] else '') + '（右键可复制）\n', 'meta')
                self.codes.append(block[2])
                self.insert(block[2] + '\n\n', 'code')
            elif kind == 'table':
                self.insert(table_lines(block[1]) + '\n', 'table')
            elif kind == 'heading':
                self.inline(block[2], 'heading')
                self.insert('\n', 'heading')
            elif kind == 'rule':
                self.insert('────────────────────\n', 'meta')
            else:
                self.inline(block[1], 'quote' if kind == 'quote' else 'body')
                self.insert('\n', 'body')

    def render(self, entries, agent_mode):
        self._recording = []
        self.codes = []
        self.stats = {}
        for entry in entries:
            self.insert('你\n', 'role')
            if entry.get('target_label'):
                self.insert(entry['target_label'] + '\n', 'meta')
            frozen = entry.get('context_snapshot') or entry.get('selection_at_send')
            if frozen:
                self.insert(selection_text(frozen) + '\n', 'meta')
            self.insert(entry['input'] + '\n', 'user')
            self.insert('XunChi Agent\n' if agent_mode else '本地回显 · 未连接 LLM\n', 'role')
            if agent_mode:
                self.markdown(entry.get('answer', ''))
                for text, tag in operation_lines(entry.get('operation_summary')):
                    self.insert(text + '\n', tag)
                status = entry.get('state')
                if status != 'completed':
                    label = {'queued': '等待发送', 'running': '回答中…', 'cancelling': '正在停止…', 'cancelled': '已停止 · 保留已收到的内容', 'failed': '请求失败'}.get(status, '')
                    self.insert(label + '\n', 'meta')
                    if entry.get('error'):
                        self.insert(entry['error'].get('message', '') + '\n', 'meta')
            else:
                self.insert(entry.get('echo', '') + '\n', 'body')
            self.insert('\n', 'body')
        plan = self._recording
        self._recording = None
        return self.apply_plan(plan)

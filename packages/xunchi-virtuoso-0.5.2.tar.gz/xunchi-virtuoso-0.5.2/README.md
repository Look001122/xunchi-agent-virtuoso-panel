# XunChi Agent Virtuoso 插件 V0.5.2

V0.5.2修复SKILL操作结束后面板状态提示残留：原生操作可能晚于Agent请求结束，执行标记清除后会恢复对应的完成、失败、停止或连接状态；仍在执行时继续提示等待，不将停止Agent等待视为终止原生操作。

在Virtuoso停靠面板内输入中文，通过现有XunChi Agent/LLM查询和操作当前Virtuoso设计，并显示真实工具结果与回答。

## 本次修复：Layout L / XL 应用切换后菜单恢复

- Cadence切换到XL会重建banner菜单，却不重新触发cellview打开回调。新增幂等菜单检查，仅在菜单缺失时补装，每2秒检查一次。
- 热加载时旧检查链由epoch失效，不累积轮询；保留其他厂商/用户菜单与触发器，不移动面板，不改变关联设计，也不重建聊天会话。
- 扩展仍需正常加载初始化配置。使用`-nocdsinit`启动的GUI会跳过用户安装；本项目的候选查看启动器已修正为正常启动并显示面板。

## 保留：选择快照与工具结果摘要

- 输入框上方显示当前关联设计的选择数量与最多6个对象名称/类型。发送后在消息中保留当时选择，并由同一Virtuoso进程校验、冻结上下文。
- 发送到执行之间换选对象，即使数量相同，也拒绝该次SKILL执行并提示重新核对；切换关联设计仍由目标标识检查。
- 同一轮中Agent自身成功执行导致的选择变化可继续衔接；工程师另行换选仍会拒绝后续SKILL执行。重试遇到选择变化时回填原问题，核对后再发送。
- 助手回答之后显示独立的“执行结果摘要 · 工具证据”：实际执行/失败次数、对象变化、字段前后值、选区外变化、Shell退出情况及待验证内容。
- 摘要来自关联视图顶层对象的前后采样，最多扫描5000个对象；超过上限明确标注不可用。它不记录完整编辑历史，不能识别所有中间变化或删除后复用同一OA对象ID的情况；其他视图、层次内部、Shell和异步效果需另行核对。
- 选择检查约束本插件的SKILL执行入口；已授权的Shell及文件工具不处于该选择检查的系统沙盒内。摘要不自动判定匹配、连通性、DRC/LVS或性能通过。

## 保留的滚动修复

流式增量只修改显示文本的变化片段，不再清空并重建整段聊天。历史样式、阅读锚点与文字选择保持稳定。

- 默认跟随最新回答，发送新消息也会回到最新。
- 向上滚动或选择历史文字时暂停跟随，后续流式内容不拉走阅读位置。
- 点击“最新”恢复持续跟随；手动向下滚到底部也恢复跟随。
- 滚动意图由鼠标/键盘事件明确维护，布局重新计算不再被误判为用户滚动；过时的异步恢复任务会取消。

## 使用

正常启动Virtuoso、打开layout或schematic，点击 **XunChi Agent → Open Chat Panel**。首次打开会启动本机专属Agent服务，准备好后可提问：

> 当前打开的是什么设计？现在选中了哪些对象？请给出名称、类型和数量。

- **Enter发送、Shift+Enter换行**；拼音预编辑时Enter先交给输入法。
- 等待回答时Virtuoso界面继续响应，可看到等待、回答中、查询设计、完成或失败状态。
- 原生X和 **Hide Panel** 隐藏面板；菜单重开后保留聊天记录和同一Agent会话。
- **停止** 请求取消当前工作；**重连** 重启本面板的Agent服务，并在原会话仍存在时恢复它。
- **清空显示** 只清理面板显示，保留Agent会话上下文。
- 回答支持标题、强调、行内代码、代码块和表格；代码块可右键复制，顶部可复制回答或回到最新内容。
- 文本通过真实Agent事件流逐步显示；状态区区分等待、模型处理、工具调用、生成、完成与失败。停止保留已收到的内容，重试生成独立新请求。
- 输入区上沿可拖动调整高度，面板随窗口尺寸变化调整布局。
- 顶部下拉框显式选择关联设计，**关联当前** 绑定当前编辑窗口。点击面板或切换焦点不自动改绑；关联窗口关闭后提示并禁用发送。

本版一个Virtuoso进程保留一个聊天面板，停靠位置保持在首次打开的会话窗口中；可显式关联同进程的其他设计窗口。跨设计关联不销毁面板，不清空聊天，也不移动工程师原有的设计窗口。

## 已授权的设计操作

用户已明确授权全部设计操作，原只读限制已解除：

- `get_design_context`：查询关联窗口的LCV、访问模式、选择数量、名称与类型。
- `execute_skill`：在同一Virtuoso进程执行SKILL源代码，可调用本机可用的创建、修改、删除、保存及其他设计API，返回最后一个表达式的值和stdout。
- Agent已有的Bash、文件读取和编辑等工具已开放，可运行仿真、DRC/LVS、提取、网表及其他设计流程所需Shell命令。

授权不改变实际视图的r/a/w模式、文件锁、Linux账户权限、许可证或已安装软件。当前演示视图仍以r模式打开；需要编辑时使用正常Cadence流程打开可写设计。仿真和验证需结合实际环境、命令与工程配置执行，成功结论来自日志或报告。

`execute_skill`同步执行，可能占用Virtuoso主事件线程；长任务使用Shell后台作业或厂商异步接口。停止Agent等待不一定中断已经进入Virtuoso的同步代码。执行异常不会自动回滚已完成的表达式，超时后先核对状态再重试，避免重复写操作。工具仍检查目标标识并拒绝错误目标。

子代理分派与面板尚未实现的question专用交互通道保持关闭；需要澄清时Agent以普通中文回复。凭据、许可证正文、PDK原始定义和无关系统设置不属于普通工程设计修改范围。

## 分工与运行链路

```text
菜单/SKILL
  → panel_session.sh：启动与监督整个面板会话
      ├─ Python/Gtk：中文输入、显示、按钮与嵌入窗口
      └─ agent_service.sh：启动现有Agent服务、curl HTTP收发、状态和取消
           → 现有Agent/LLM
              → virtuoso_mcp.sh：Bash/jq处理设计工具协议
                 → design_tools.il：同进程查询或执行SKILL设计代码
```

- **Shell**：启动、HTTP、工具协议和进程清理。
- **SKILL**：所有Virtuoso设计数据查询及目标校验。
- **Python**：已有中文GUI与X11嵌入。沿用此前的Python安装器，以及现有Agent产品的连接启动器；新业务后端不使用Python HTTP工作进程。

每条提问带独立请求ID与目标标识。目标在查询前改变时返回 `TARGET_CHANGED`，不会静默改查另一个设计。设计事实必须来自本轮实时工具结果，不用面板摘要替代查询。

## 依赖与安装

本机运行环境：CentOS7/Linux X11、Virtuoso IC618、Bash4.2、curl7.29、系统 `/usr/bin/python` 的GI/Gtk3/GdkX11。包内带官方静态jq，版本与校验见 `THIRD_PARTY.md`，不替换系统程序。

还需要已安装、已有可用连接的XunChi Agent。本机复用：

- Agent：`~/.local/opt/xunchi-agent-0.1.2-chatgpt.1/`，可通过 `XUNCHI_AGENT_HOME` 指定其他目录。
- 现有连接启动器所用Python3：`/opt/eda/mentor/calibre2019/aoj_cal_2019.3_15.11/pkgs/icv_python/asp/bin/python3`，可通过 `XUNCHI_VIRTUOSO_PYTHON3` 指定。

安装器要求Python3.6+标准库。解压发布包后：

```sh
python3 install.py install
```

从0.5.1升级：

```sh
python3 install.py install --upgrade-from ~/.local/share/xunchi-virtuoso/0.5.1
```

默认安装到 `~/.local/share/xunchi-virtuoso/0.5.2/`，核对旧清单、备份启动文件后替换 `~/.cdsinit` 的受管加载块，保留旧目录。重复安装幂等，文件被修改则停止并保留。

配置只在启动时加载。升级后正常重启Virtuoso，使新菜单及其专属Agent服务使用新配置；已运行的其他Agent/TUI不需要退出。`-nocdsinit` 开发启动方式不读该加载块。若项目/站点 `.cdsinit` 优先且不加载用户配置，使用 `--cdsinit /path/to/user-maintained/.cdsinit` 指定真实启动文件。符号链接需指定真实目标，当前安装路径要求ASCII。

## 日志与卸载

面板会话记录位于 `~/.local/state/xunchi-virtuoso/session-*`：

- `agent_history.json`：面板记录；`agent_session.json`：Agent会话ID。
- `agent_turns.jsonl`：本面板各轮的真实回答与Agent工具调用。
- `tool_calls.jsonl`、`tool-response-*.json`：实时SKILL结果。
- `agent_state.json`、`transport_state.json`：状态和本面板启动的进程标识。
- `agent_transport.log`、`agent_server.log`、`chat.log`：分层日志。
- `stream_frames.jsonl`：分请求的回答增量和阶段信息，不包含模型思考原文。
- `skill-code-*.il`、`skill-output-*.log`：已提交的SKILL代码和stdout；`tool.executing`存在表示同步操作仍在进行。

服务只监听127.0.0.1，独立的本机访问凭据由Shell生成并在退出时清理；复用既有连接启动器处理模型鉴权，不复制模型密钥到插件包。

```sh
python3 ~/.local/share/xunchi-virtuoso/0.5.2/install.py uninstall
```

卸载移除受管加载块和未修改的安装文件，保留其他配置及会话记录。正在运行的Virtuoso需重启才能卸载会话内菜单。

## 开发验证与打包

```sh
python3 -m unittest discover -s tests -v
PYTHONDONTWRITEBYTECODE=1 /usr/bin/python tests/test_tool_status.py
python3 tests/launch_native.py
bash tests/check_live_tool.sh --run /path/to/native-run
bash tests/check_design_permissions.sh --run /path/to/native-run
python3 tests/authorized_agent_gui.py --run /path/to/native-run
python3 tests/scroll_live_gui.py --run /path/to/native-run
python3 tests/launch_native.py --selection-fixture
bash tests/check_selection.sh --run /path/to/selection-run
python3 tests/selection_agent_gui.py --run /path/to/selection-run
bash tests/verify_selection.sh --run /path/to/selection-run
python3 install.py package --output /path/to/xunchi-virtuoso-0.5.2.tar.gz
```

GUI检查需保持专用验收窗口可见。默认演示视图只读；`--selection-fixture` 额外建立独立可写临时库，只在此库测试修改。`launch_native.py --offline` 是显式本地回显回归模式，不代表LLM已联通，生产菜单默认使用真实Agent；连接失败不会降级成假回答。

本机嵌入依赖Gtk外来子窗口和XEmbed，并非Cadence官方第三方组件嵌入API。IC618有时忽略初始宽度提示，因此本版在面板过窄且所属窗口处于前台、鼠标未按住时，短暂操作自身分隔条恢复首选宽度，随后恢复指针和键盘焦点；不会切换输入法引擎。可设置 `XUNCHI_VIRTUOSO_NO_AUTO_SIZE=1` 关闭该兼容处理并手动调整宽度。浮动停靠和其他Virtuoso/窗口管理器版本尚待适配。

Markdown为本地文本渲染子集，不执行HTML、脚本或代码块。运行中停止表示向Agent请求中断，不保证所有模型后端即时停止推理或计费。整台Virtuoso退出后的自动会话恢复尚未实现。

前期验收记录保留，设计权限版验证见 `V0.4.0_验收记录.md`，滚动修复见开发目录的 `V0.4.1_验收记录.md`，选择与结果摘要验证见开发目录的 `V0.5.0_验收记录.md`。整机重启后的自动聊天恢复尚未实现；维护时的面板重载可复用原会话目录，保留原生宿主、设计关联、历史、输入草稿与Agent session。

; V0.4.1: embedded conversation and idle UI reload with preserved design/session.
unless(boundp('xcU12Dock) xcU12Dock=nil)
unless(boundp('xcU12Form) xcU12Form=nil)
unless(boundp('xcU12Target) xcU12Target=nil)
unless(boundp('xcU12Worker) xcU12Worker=nil)
unless(boundp('xcU12Run) xcU12Run=nil)
unless(boundp('xcU12Epoch) xcU12Epoch=0)
unless(boundp('xcU12Buffer) xcU12Buffer="")
unless(boundp('xcU12Status) xcU12Status="idle")

procedure(xcU12CellView(win)
 let((answer)
   when(win && win!=hiGetCIWindow() && member(win hiGetWindowList('window)) && hiGetWidgetType(win)=="graphics"
   answer=errset(geGetEditCellView(win) nil)
   when(answer car(answer))
  )
 ))

procedure(xcU12Quote(text)
 let((out char)
  out="'"
  for(i 1 strlen(text)
   char=substring(text i 1)
   out=strcat(out if(char=="'" then "'\"'\"'" else char)))
  strcat(out "'")
 ))

procedure(xcU12WriteContext()
 let((cv f)
  when(xcU12Run
   cv=xcU12CellView(xcU12Target)
   xcV02Meta(cv)
   f=outfile(strcat(xcU12Run "/context.txt"))
   when(f
    if(cv then
     fprintf(f "%s\n%s\n%s\n%d\n" cv~>libName cv~>cellName cv~>viewName length(geGetSelSet(xcU12Target)))
     else fprintf(f "No target design\n-\n-\n0\n"))
    close(f)
   )
  )
 ))

procedure(xcU12Hide()
 when(xcU12Dock && member(xcU12Dock hiGetWindowList('dockable)) hiUnmapWindow(xcU12Dock))
 t
)

procedure(xcU12Destroy()
 xcU12Epoch=xcU12Epoch+1
 when(xcU12Dock && member(xcU12Dock hiGetWindowList('dockable)) hiCloseWindow(xcU12Dock))
 xcU12Dock=nil
 when(xcU12Form hiDeleteForm(xcU12Form) xcU12Form=nil)
 when(xcU12Worker && ipcIsAliveProcess(xcU12Worker) ipcKillProcess(xcU12Worker))
 xcU12Worker=nil xcU12Status="idle"
 t
)

procedure(xcU12Poll(epoch)
 when(epoch==xcU12Epoch && xcU12Dock && member(xcU12Dock hiGetWindowList('dockable))
  xcU12WriteContext()
  xcV02HandleTool()
  when(isFile(strcat(xcU12Run "/bind.request"))
   let((f requested match)
    f=infile(strcat(xcU12Run "/bind.request"))
    requested=car(parseString(gets(nil f) "\n")) close(f)
    deleteFile(strcat(xcU12Run "/bind.request"))
    if(requested=="current" then match=hiGetCurrentWindow()
     else match=car(setof(win hiGetWindowList('window) sprintf(nil "%L" win)==requested)))
    when(xcU12CellView(match) xcU12Open(match))
   ))
  ; Local control files are also used by the isolated acceptance harness.
  when(isFile(strcat(xcU12Run "/hide.request"))
   deleteFile(strcat(xcU12Run "/hide.request")) xcU12Hide())
  when(isFile(strcat(xcU12Run "/show.request"))
   deleteFile(strcat(xcU12Run "/show.request"))
   hiMapWindow(xcU12Dock))
  hiRegTimer(sprintf(nil "xcU12Poll(%d)" epoch) 5)
 )
)

procedure(xcU12CreateHost()
  let((f placeholder)
  unless(xcU12CellView(xcU12Target) error("Target closed while starting XunChi Agent"))
  placeholder=hiCreateLabel(?name 'xcU12Placeholder ?labelText "Preparing XunChi Agent conversation panel...")
  xcU12Form=hiCreateAppForm(?name 'xcU12Form ?formTitle "XunChi Agent" ?buttonLayout 'Empty
   ?formType 'nonOptions ?fields list(list(placeholder 0:0 580:460)))
  xcU12Dock=hiCreateDockWindow(?appType "XunChiAgentConversation" ?widgetType "form"
   ?handle 'xcU12PanelHandle ?form xcU12Form ?title "XunChi Agent"
   ?dockSizeHint list(600 680) ?floatSizeHint list(600 640) ?minimumSizeHint list(360 460) ?scrollBar nil)
  hiSetWinObjName(xcU12Dock "XunChiAgentConversation")
  xcU12Dock->neverCurrentWindow=t
  hiDockWindow(?window xcU12Dock ?session hiGetSessionWindow(xcU12Target) ?side 'right)
  xcU12WriteContext()
  f=outfile(strcat(xcU12Run "/host.ready")) fprintf(f "READY\n") close(f)
  xcU12Poll(xcU12Epoch)
 ))

procedure(xcU12Data(cid data)
 let((position line tail)
  when(cid==xcU12Worker
   xcU12Buffer=strcat(xcU12Buffer data)
   while(tail=index(xcU12Buffer "\n")
    position=strlen(xcU12Buffer)-strlen(tail)+1
    line=if(position>1 then substring(xcU12Buffer 1 position-1) else "")
    xcU12Buffer=if(position<strlen(xcU12Buffer) then substring(xcU12Buffer position+1) else "")
    cond(
     (strlen(line)>7 && substring(line 1 7)=="XC_RUN "
      xcU12Run=substring(line 8)
      unless(errset(xcU12CreateHost() t) xcU12Status="failed" ipcKillProcess(cid)))
     (strlen(line)>10 && substring(line 1 10)=="XC_RESUME " xcU12Run=substring(line 11))
     (line=="XC_READY" xcU12Status="ready")
     (strlen(line)>=8 && substring(line 1 8)=="XC_ERROR"
      xcU12Status="failed"
      when(xcU12Form xcU12Form->xcU12Placeholder->value="UI startup failed. See CIW and session log.")
      warn("XunChi Agent: %s\n" line))
     (strlen(line)>0 printf("XunChi UI: %s\n" line))
    )
   )
  )
 ))

procedure(xcU12ReloadUI()
 let((previous command)
  unless(xcU12Run && xcU12Dock && member(xcU12Dock hiGetWindowList('dockable))
   error("No existing panel to reload"))
  previous=xcU12Worker xcU12Worker=nil
  xcU12Epoch=xcU12Epoch+1
  when(previous && ipcIsAliveProcess(previous) ipcKillProcess(previous))
  xcU12Buffer="" xcU12Status="starting"
  xcU12WriteContext()
  command=sprintf(nil "/bin/bash %s --pid %d --resume %s"
   xcU12Quote(strcat(xcPluginRoot "/panel_session.sh")) ipcGetPid() xcU12Quote(xcU12Run))
  xcU12Worker=ipcBeginProcess(command "" 'xcU12Data 'xcU12Data 'xcU12Exited)
  xcU12Poll(xcU12Epoch)
  t
 ))

procedure(xcU12Exited(cid status)
 when(cid==xcU12Worker
  xcU12Worker=nil
  xcU12Status=if(status==0 then "closed" else "failed")
  when(status!=0 warn("XunChi Agent UI exited (%d). Reopen from the menu to retry.\n" status))
 )
)

procedure(xcU12Open(@optional target)
 let((command)
  unless(target target=hiGetCurrentWindow())
  unless(xcU12CellView(target) error("Open XunChi Agent from a layout or schematic window"))
  cond(
   (xcU12Worker && ipcIsAliveProcess(xcU12Worker) && !xcU12Dock
    printf("XunChi Agent is starting; please wait.\n"))
   (xcU12Worker && ipcIsAliveProcess(xcU12Worker) && xcU12Dock &&
    member(xcU12Dock hiGetWindowList('dockable))
    ; Keep the conversation host stable. Binding another editor must not
    ; recreate/re-dock the foreign UI or reset the engineer's chosen width.
    xcU12Target=target xcU12WriteContext()
    hiMapWindow(xcU12Dock)
    hiRaiseWindow(xcU12Dock))
   (t
    xcU12Destroy()
    xcU12Target=target xcU12Run=nil xcU12Buffer="" xcU12Status="starting"
    command=sprintf(nil "/bin/bash %s --pid %d"
     xcU12Quote(strcat(xcPluginRoot "/panel_session.sh")) ipcGetPid())
    xcU12Worker=ipcBeginProcess(command "" 'xcU12Data 'xcU12Data 'xcU12Exited)
   )
  )
  xcU12Worker
 ))

; User extension only. Does not replace application or other user triggers.
unless(boundp('xcPluginRegisteredViews) xcPluginRegisteredViews=nil)
unless(boundp('xcPluginMenu) xcPluginMenu=nil)
unless(boundp('xcPluginMenuEpoch) xcPluginMenuEpoch=0)

procedure(xcPluginOpenAction()
 when(boundp('xcV01Visible) && xcV01Visible xcAgentV01Close())
 xcU12Open(hiGetCurrentWindow())
)

procedure(xcPluginBuildMenu()
 unless(xcPluginMenu
  xcPluginMenu=hiCreatePulldownMenu('xcPluginMenu "XunChi Agent"
   list(
    hiCreateMenuItem(?name 'xcPluginOpen ?itemText "Open Chat Panel"
     ?callback "xcPluginOpenAction()")
    hiCreateMenuItem(?name 'xcPluginClose ?itemText "Hide Panel"
     ?callback "xcU12Hide()")
   ))
 )
 hiSetMenuItemText(xcPluginMenu 'xcPluginOpen "Open Chat Panel")
 hiSetMenuItemCallback(xcPluginMenu 'xcPluginOpen "xcPluginOpenAction()")
 hiSetMenuItemCallback(xcPluginMenu 'xcPluginClose "xcU12Hide()")
 xcPluginMenu
)

procedure(xcPluginMenuTrigger(args)
 list(xcPluginBuildMenu())
)

procedure(xcPluginAttachExisting()
 let((cv menus)
  foreach(win hiGetWindowList('window)
   cv=xcU12CellView(win)
   when(cv && member(cv~>cellViewType list("maskLayout" "schematic"))
    menus=hiGetBannerMenus(win)
    unless(member('xcPluginMenu menus)
     hiInsertBannerMenu(win xcPluginBuildMenu() length(menus))
    )
   )
  )
  t
 ))

procedure(xcPluginInstall()
 xcPluginBuildMenu()
 foreach(viewType list("maskLayout" "schematic")
  unless(member(viewType xcPluginRegisteredViews)
   when(deRegUserTriggers(viewType nil 'xcPluginMenuTrigger)
    xcPluginRegisteredViews=cons(viewType xcPluginRegisteredViews))
  )
 )
  xcPluginAttachExisting()
  ; L -> XL rebuilds menus without reopening the view. Reconcile only
  ; missing entries; never move/rebind/recreate the conversation dock.
  xcPluginMenuEpoch=xcPluginMenuEpoch+1
  hiRegTimer(sprintf(nil "xcPluginWatchMenus(%d)" xcPluginMenuEpoch) 20)
  printf("XunChi Agent V0.5.2 menu installed (XL app-switch recovery).\n")
 t
)

procedure(xcPluginWatchMenus(epoch)
 when(epoch==xcPluginMenuEpoch
  errset(xcPluginAttachExisting() t)
  hiRegTimer(sprintf(nil "xcPluginWatchMenus(%d)" epoch) 20)
 )
)

xcPluginInstall()

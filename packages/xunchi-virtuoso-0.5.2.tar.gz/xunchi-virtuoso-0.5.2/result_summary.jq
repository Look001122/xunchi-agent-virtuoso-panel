($result[0].tools // []) as $tools |
($audit | map(select(.request_id==$id and .tool=="execute_skill"))) as $calls |
[$calls[].result.changes | select(.available==true)] as $diffs |
[$diffs[].objects[]?] as $events |
[$events | group_by(.object_id)[] |
 {object_id:.[0].object_id,name:.[-1].name,object_type:.[-1].object_type,
  statuses:([.[].status]|unique),was_selected:any(.[]; .was_selected==true),
  fields:[.[].fields[]?]}] as $objects |
{source:"tool_evidence",state:$state,native_calls:($calls|length),
 executed_calls:([$calls[]|select(.result.executed==true)]|length),
 native_failures:[$calls[]|select(.result.ok!=true)|{code:.result.error.code,message:.result.error.message}],
 observations:{created:([$diffs[].created]|add//0),modified:([$diffs[].modified]|add//0),deleted:([$diffs[].deleted]|add//0)},
 unique_objects_in_details:($objects|length),objects:$objects[:12],
 details_truncated:(($objects|length)>12 or any($diffs[]; .details_truncated==true)),
 outside_selection_observations:([$diffs[].outside_initial_selection]|add//0),
 coverage:["仅关联视图顶层对象的执行前后采样；中间变化、删除后复用同一对象ID、其他视图、层次内部、Shell及异步后续变化不属于完整差异证明"],
 unavailable:[$calls[]|.result.changes|select(.available==false)|.reason],
 shell_calls:([$tools[]|select(.tool=="bash")]|length),
 shell_failures:[$tools[]|select(.tool=="bash" and (.state.status=="error" or (.state.metadata.exit//0)!=0))|
   {status:.state.status,exit_code:.state.metadata.exit}],
 verification:"任务目标、匹配、连通性及工艺/性能结论需结合正文和实际报告核对；本摘要不自动认定通过"}

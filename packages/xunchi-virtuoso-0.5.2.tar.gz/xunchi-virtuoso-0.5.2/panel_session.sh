#!/bin/bash
# SKILL -> Bash session supervisor -> Python GUI + Bash Agent transport.
set -uo pipefail
source "$(dirname -- "$0")/shell_common.sh"
[[ ${1:-} == --pid && ${2:-} =~ ^[0-9]+$ ]] || exit 2
virtuoso_pid=$2
resume=
if [[ ${3:-} == --resume && -d ${4:-} ]]; then resume=$4; fi
base="$HOME/.local/state/xunchi-virtuoso"
mkdir -p -- "$base"
launch_dir=$(mktemp -d "$base/launch-${virtuoso_pid}-XXXXXX") || exit 1
mkfifo "$launch_dir/gui.pipe"
gui_pid= service_pid= run=
pending_line=
cleanup() {
    trap - EXIT TERM INT HUP
    stop_pid "$service_pid"
    stop_pid "$gui_pid"
    rm -f -- "$launch_dir/gui.pipe"
}
trap cleanup EXIT
trap 'exit 143' TERM HUP
trap 'exit 130' INT
unset LD_LIBRARY_PATH LD_PRELOAD
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8 PYTHONDONTWRITEBYTECODE=1
gui_command=(/usr/bin/python -B "$ROOT/bridge.py" --pid "$virtuoso_pid")
if [[ -n "$resume" ]]; then
    old_gui=$("$JQ" -r '.chat_pid // 0' "$resume/launch.json")
    old_server=0
    [[ -f "$resume/transport_state.json" ]] && old_server=$("$JQ" -r '.server_pid // 0' "$resume/transport_state.json")
    for old_pid in "$old_gui" "$old_server"; do
        [[ "$old_pid" =~ ^[1-9][0-9]*$ ]] || continue
        for ((i=0; i<150; i++)); do
            stat=$(ps -p "$old_pid" -o stat= 2>/dev/null) || stat=
            [[ -z "$stat" || "$stat" == Z* ]] && break
            sleep .1
        done
        if [[ -n "$stat" && "$stat" != Z* ]]; then
            printf 'XC_ERROR Previous panel process has not stopped; retry reload when idle\n'
            exit 1
        fi
    done
    gui_command+=(--resume "$resume")
fi
"${gui_command[@]}" >"$launch_dir/gui.pipe" 2>"$launch_dir/gui.stderr.log" &
gui_pid=$!
exec 3<"$launch_dir/gui.pipe"
while kill -0 "$gui_pid" 2>/dev/null; do
    line=
    if IFS= read -r -t .2 line <&3; then
        line="$pending_line$line"
        pending_line=
        printf '%s\n' "$line"
        case "$line" in
            'XC_RUN '*) run=${line#XC_RUN } ;;
            'XC_RESUME '*) run=${line#XC_RESUME } ;;
            XC_READY)
                if [[ ${XUNCHI_VIRTUOSO_TEST_LOCAL_ECHO:-0} != 1 ]]; then
                    /bin/bash "$ROOT/agent_service.sh" --run "$run" >>"$run/agent_transport.log" 2>&1 &
                    service_pid=$!
                fi ;;
        esac
    else
        pending_line="$pending_line$line"
    fi
    if [[ -n "$run" && -f "$run/restart_agent.request" && ${XUNCHI_VIRTUOSO_TEST_LOCAL_ECHO:-0} != 1 ]]; then
        rm -f -- "$run/restart_agent.request"
        stop_pid "$service_pid"
        /bin/bash "$ROOT/agent_service.sh" --run "$run" >>"$run/agent_transport.log" 2>&1 &
        service_pid=$!
    fi
done
wait "$gui_pid"
exit $?

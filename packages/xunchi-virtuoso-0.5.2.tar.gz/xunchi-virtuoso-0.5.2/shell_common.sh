#!/bin/bash
# Shared data-only JSON helpers. All network/process orchestration stays in Bash.
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
JQ=${XUNCHI_VIRTUOSO_JQ:-"$ROOT/jq-linux-amd64"}
[[ -x "$JQ" ]] || { printf 'jq executable unavailable: %s\n' "$JQ" >&2; exit 1; }
umask 077

jwrite() {
    local destination=$1 temporary
    shift
    temporary=$(mktemp "${destination}.tmp.XXXXXX") || return 1
    if "$JQ" "$@" >"$temporary"; then
        mv -f -- "$temporary" "$destination"
    else
        rm -f -- "$temporary"
        return 1
    fi
}

uuid_hex() {
    local value
    IFS= read -r value </proc/sys/kernel/random/uuid
    printf '%s' "${value//-/}"
}

stop_pid() {
    local pid=${1:-} i
    [[ "$pid" =~ ^[0-9]+$ ]] || return 0
    kill -TERM "$pid" 2>/dev/null || return 0
    for ((i=0; i<80; i++)); do
        kill -0 "$pid" 2>/dev/null || break
        sleep .1
    done
    kill -KILL "$pid" 2>/dev/null || :
    wait "$pid" 2>/dev/null || :
}

"""Small X11 adapter for the isolated embedding experiment (no Qt injection)."""
from __future__ import print_function
import ctypes as C
import ctypes.util
import os


class Attributes(C.Structure):
    _fields_ = [('x', C.c_int), ('y', C.c_int), ('width', C.c_int),
                ('height', C.c_int), ('border_width', C.c_int), ('depth', C.c_int),
                ('visual', C.c_void_p), ('root', C.c_ulong), ('klass', C.c_int),
                ('bit_gravity', C.c_int), ('win_gravity', C.c_int),
                ('backing_store', C.c_int), ('backing_planes', C.c_ulong),
                ('backing_pixel', C.c_ulong), ('save_under', C.c_int),
                ('colormap', C.c_ulong), ('map_installed', C.c_int),
                ('map_state', C.c_int), ('all_event_masks', C.c_long),
                ('your_event_mask', C.c_long), ('do_not_propagate_mask', C.c_long),
                ('override_redirect', C.c_int), ('screen', C.c_void_p)]


class MessageData(C.Union):
    _fields_ = [('b', C.c_char * 20), ('s', C.c_short * 10), ('l', C.c_long * 5)]


class ClientMessage(C.Structure):
    _fields_ = [('type', C.c_int), ('serial', C.c_ulong), ('send_event', C.c_int),
                ('display', C.c_void_p), ('window', C.c_ulong),
                ('message_type', C.c_ulong), ('format', C.c_int), ('data', MessageData)]


class Event(C.Union):
    _fields_ = [('client', ClientMessage), ('pad', C.c_long * 24)]


class X11(object):
    def __init__(self):
        self.x = C.CDLL(ctypes.util.find_library('X11'))
        self._bind('XOpenDisplay', [C.c_char_p], C.c_void_p)
        self._bind('XDefaultRootWindow', [C.c_void_p], C.c_ulong)
        self._bind('XGetWindowAttributes', [C.c_void_p, C.c_ulong, C.POINTER(Attributes)], C.c_int)
        self._bind('XQueryTree', [C.c_void_p, C.c_ulong, C.POINTER(C.c_ulong),
                                 C.POINTER(C.c_ulong), C.POINTER(C.POINTER(C.c_ulong)),
                                 C.POINTER(C.c_uint)], C.c_int)
        self._bind('XFetchName', [C.c_void_p, C.c_ulong, C.POINTER(C.c_void_p)], C.c_int)
        self._bind('XFree', [C.c_void_p], C.c_int)
        self._bind('XInternAtom', [C.c_void_p, C.c_char_p, C.c_int], C.c_ulong)
        self._bind('XGetWindowProperty', [C.c_void_p, C.c_ulong, C.c_ulong,
                   C.c_long, C.c_long, C.c_int, C.c_ulong, C.POINTER(C.c_ulong),
                   C.POINTER(C.c_int), C.POINTER(C.c_ulong), C.POINTER(C.c_ulong),
                   C.POINTER(C.c_void_p)], C.c_int)
        self._bind('XReparentWindow', [C.c_void_p, C.c_ulong, C.c_ulong, C.c_int, C.c_int], C.c_int)
        self._bind('XMoveResizeWindow', [C.c_void_p, C.c_ulong, C.c_int, C.c_int,
                                       C.c_uint, C.c_uint], C.c_int)
        self._bind('XSetInputFocus', [C.c_void_p, C.c_ulong, C.c_int, C.c_ulong], C.c_int)
        self._bind('XGetInputFocus', [C.c_void_p, C.POINTER(C.c_ulong), C.POINTER(C.c_int)], C.c_int)
        self._bind('XSendEvent', [C.c_void_p, C.c_ulong, C.c_int, C.c_long, C.POINTER(Event)], C.c_int)
        self._bind('XTranslateCoordinates', [C.c_void_p, C.c_ulong, C.c_ulong,
                   C.c_int, C.c_int, C.POINTER(C.c_int), C.POINTER(C.c_int),
                   C.POINTER(C.c_ulong)], C.c_int)
        self._bind('XMapWindow', [C.c_void_p, C.c_ulong], C.c_int)
        self._bind('XSync', [C.c_void_p, C.c_int], C.c_int)
        self._bind('XCloseDisplay', [C.c_void_p], C.c_int)
        self._bind('XQueryPointer', [C.c_void_p, C.c_ulong, C.POINTER(C.c_ulong), C.POINTER(C.c_ulong),
                   C.POINTER(C.c_int), C.POINTER(C.c_int), C.POINTER(C.c_int), C.POINTER(C.c_int), C.POINTER(C.c_uint)], C.c_int)
        self.display = self.x.XOpenDisplay(os.environ.get('DISPLAY', ':0').encode())
        if not self.display:
            raise RuntimeError('Cannot open X display')
        # A destroyed host is an expected lifecycle event, not a process abort.
        self.errors = []
        callback = C.CFUNCTYPE(C.c_int, C.c_void_p, C.c_void_p)
        self.error_handler = callback(lambda display, event: self.errors.append('X error') or 0)
        self.x.XSetErrorHandler.argtypes = [callback]
        self.x.XSetErrorHandler(self.error_handler)
        self.root = self.x.XDefaultRootWindow(self.display)

    def _bind(self, name, args, result):
        function = getattr(self.x, name)
        function.argtypes = args
        function.restype = result

    def attributes(self, window):
        result = Attributes()
        if not self.x.XGetWindowAttributes(self.display, window, C.byref(result)):
            return None
        return result

    def children(self, window):
        root, parent, count = C.c_ulong(), C.c_ulong(), C.c_uint()
        items = C.POINTER(C.c_ulong)()
        ok = self.x.XQueryTree(self.display, window, C.byref(root), C.byref(parent),
                              C.byref(items), C.byref(count))
        result = [items[i] for i in range(count.value)] if ok else []
        if items:
            self.x.XFree(items)
        return parent.value, result

    def pid(self, window):
        actual, count, remaining = C.c_ulong(), C.c_ulong(), C.c_ulong()
        fmt, data = C.c_int(), C.c_void_p()
        atom = self.x.XInternAtom(self.display, b'_NET_WM_PID', 0)
        self.x.XGetWindowProperty(self.display, window, atom, 0, 1, 0, 0,
                                 C.byref(actual), C.byref(fmt), C.byref(count),
                                 C.byref(remaining), C.byref(data))
        value = C.cast(data, C.POINTER(C.c_ulong))[0] if data and count.value and fmt.value == 32 else None
        if data:
            self.x.XFree(data)
        return value

    def name(self, window):
        text = C.c_void_p()
        self.x.XFetchName(self.display, window, C.byref(text))
        result = C.string_at(text).decode('utf-8', 'replace') if text else ''
        if text:
            self.x.XFree(text)
        return result

    def snapshot(self, pid):
        result = {}

        def visit(window, inherited_pid, depth):
            owner = self.pid(window) or inherited_pid
            attributes = self.attributes(window)
            parent, children = self.children(window)
            if attributes and owner == pid:
                result[str(window)] = {'id': window, 'parent': parent, 'depth': depth,
                    'width': attributes.width, 'height': attributes.height,
                    'x': attributes.x, 'y': attributes.y, 'map_state': attributes.map_state,
                    'name': self.name(window), 'pid': owner}
            if depth < 24:
                for child in children:
                    visit(child, owner, depth + 1)

        visit(self.root, None, 0)
        return result

    def reparent(self, window, parent, x=0, y=24):
        self.x.XReparentWindow(self.display, window, parent, x, y)
        self.x.XMapWindow(self.display, window)
        self.x.XSync(self.display, 0)

    def root_coordinates(self, window):
        x, y, child = C.c_int(), C.c_int(), C.c_ulong()
        self.x.XTranslateCoordinates(self.display, window, self.root, 0, 0,
                                     C.byref(x), C.byref(y), C.byref(child))
        return x.value, y.value

    def resize(self, window, width, height):
        self.x.XMoveResizeWindow(self.display, window, 0, 24, max(1, width), max(1, height - 24))
        self.x.XSync(self.display, 0)

    def focus(self, window):
        self.x.XSetInputFocus(self.display, window, 2, 0)
        self.x.XSync(self.display, 0)

    def fit_dock(self, host, desired):
        """IC618 fallback for ignored size hints, on the active owned splitter.

        No keyboard events are generated; the desktop pointer is restored.
        """
        import time
        parent = self.children(host)[0]
        if not self.focused_within(parent):
            return None
        attr = self.attributes(host)
        if not attr or attr.width >= desired:
            return True
        root, child = C.c_ulong(), C.c_ulong()
        rx, ry, wx, wy, mask = C.c_int(), C.c_int(), C.c_int(), C.c_int(), C.c_uint()
        self.x.XQueryPointer(self.display, self.root, C.byref(root), C.byref(child),
                            C.byref(rx), C.byref(ry), C.byref(wx), C.byref(wy), C.byref(mask))
        if mask.value & (256 | 512 | 1024):
            return None
        focused, revert = C.c_ulong(), C.c_int()
        self.x.XGetInputFocus(self.display, C.byref(focused), C.byref(revert))
        xt = C.CDLL(C.util.find_library('Xtst'))
        xt.XTestFakeMotionEvent.argtypes = [C.c_void_p, C.c_int, C.c_int, C.c_int, C.c_ulong]
        xt.XTestFakeButtonEvent.argtypes = [C.c_void_p, C.c_uint, C.c_int, C.c_ulong]
        origin = self.root_coordinates(host)
        start, y = origin[0] - 3, origin[1] + attr.height // 2
        try:
            xt.XTestFakeMotionEvent(self.display, -1, start, y, 0)
            xt.XTestFakeButtonEvent(self.display, 1, 1, 0)
            self.x.XSync(self.display, 0)
            time.sleep(.3)
            xt.XTestFakeMotionEvent(self.display, -1, start - 2, y, 0)
            self.x.XSync(self.display, 0)
            time.sleep(.1)
            for step in range(1, 7):
                xt.XTestFakeMotionEvent(self.display, -1, start - (desired - attr.width) * step // 6, y, 0)
                self.x.XSync(self.display, 0)
                time.sleep(.02)
        finally:
            xt.XTestFakeButtonEvent(self.display, 1, 0, 0)
            self.x.XSync(self.display, 0)
            time.sleep(.2)
            xt.XTestFakeMotionEvent(self.display, -1, rx.value, ry.value, 0)
            self.x.XSync(self.display, 0)
            if self.focused_within(parent) and self.attributes(focused.value):
                self.focus(focused.value)
        return self.attributes(host).width >= desired - 12

    def focused_within(self, window):
        focused, revert = C.c_ulong(), C.c_int()
        self.x.XGetInputFocus(self.display, C.byref(focused), C.byref(revert))
        current = focused.value
        for unused in range(24):
            if current == window:
                return True
            if current in (0, 1, self.root):
                return False
            current = self.children(current)[0]
        return False

    def xembed(self, child, opcode, host=0):
        event = Event()
        event.client.type = 33
        event.client.display = self.display
        event.client.window = child
        event.client.message_type = self.x.XInternAtom(self.display, b'_XEMBED', 0)
        event.client.format = 32
        event.client.data.l[0] = 0  # CurrentTime
        event.client.data.l[1] = opcode
        event.client.data.l[2] = 0
        event.client.data.l[3] = host
        event.client.data.l[4] = 0
        self.x.XSendEvent(self.display, child, 0, 0, C.byref(event))
        self.x.XSync(self.display, 0)

    def close(self):
        self.x.XCloseDisplay(self.display)

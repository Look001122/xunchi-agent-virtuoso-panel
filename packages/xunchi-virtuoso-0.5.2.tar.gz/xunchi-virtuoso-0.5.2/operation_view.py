# -*- coding: utf-8 -*-
"""Display-only formatting for frozen selection and tool-evidence summaries."""
from __future__ import unicode_literals


def object_label(obj):
    return obj.get('name') or '{} / {}'.format(obj.get('object_type', '对象'), obj.get('layer') or obj.get('object_id', '未命名'))


def selection_text(snapshot):
    if not snapshot:
        return ''
    count = snapshot.get('selected_count', snapshot.get('count', 0))
    objects = snapshot.get('selected_objects', snapshot.get('objects', []))
    names = '、'.join(object_label(obj) for obj in objects[:6])
    if count > len(objects[:6]):
        names += ' 等'
    return '发送时选择 {} 项{}'.format(count, '：' + names if names else '（无选中对象）')


def operation_lines(summary):
    if not summary or not (summary.get('native_calls') or summary.get('shell_calls')):
        return []
    lines = [('执行结果摘要 · 工具证据', 'heading')]
    counts = summary.get('observations', {})
    if summary.get('native_calls'):
        lines.append(('SKILL：实际执行 {} 次；拒绝/失败 {} 次'.format(
            summary.get('executed_calls', 0), len(summary.get('native_failures', []))), 'body'))
        lines.append(('关联视图读回：新增 {} 次、修改 {} 次、删除 {} 次（按各次执行记录统计）'.format(
            counts.get('created', 0), counts.get('modified', 0), counts.get('deleted', 0)), 'body'))
        if summary.get('outside_selection_observations'):
            lines.append(('其中 {} 次变化涉及新增或发送时未选中的对象。'.format(summary['outside_selection_observations']), 'body'))
        labels = {'created': '新增', 'modified': '修改', 'deleted': '删除'}
        for obj in summary.get('objects', []):
            lines.append(('• {} [{}]：{}{}'.format(object_label(obj), obj.get('object_type', ''),
                '/'.join(labels.get(s, s) for s in obj.get('statuses', [])),
                '' if obj.get('was_selected') else '（新增或发送时未选中）'), 'body'))
            for field in obj.get('fields', [])[:8]:
                before = field.get('before')
                after = field.get('after')
                before = '（无）' if before is None else before
                after = '（无）' if after is None else after
                before = before[:180] + ('…（截断）' if len(before) > 180 else '')
                after = after[:180] + ('…（截断）' if len(after) > 180 else '')
                lines.append(('    {}：{} → {}'.format(field.get('field', ''), before, after), 'meta'))
            if len(obj.get('fields', [])) > 8:
                lines.append(('    其余字段请查看工具原始输出。', 'meta'))
        if summary.get('details_truncated'):
            lines.append(('部分对象或字段未展开，请查看工具原始输出。', 'meta'))
        for failure in summary.get('native_failures', []):
            lines.append(('未执行/失败：{} {}'.format(failure.get('code', ''), failure.get('message', '')), 'body'))
        if summary.get('unavailable'):
            lines.append(('自动差异不可用：' + '、'.join(summary['unavailable']), 'meta'))
        lines.extend((text, 'meta') for text in summary.get('coverage', []))
    if summary.get('shell_calls'):
        lines.append(('Shell：{} 次调用，{} 次非零退出或错误；具体设计效果以输出/报告核对。'.format(
            summary['shell_calls'], len(summary.get('shell_failures', []))), 'body'))
    lines.append((summary.get('verification', ''), 'meta'))
    return lines

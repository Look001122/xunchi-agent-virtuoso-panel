#!/bin/bash
# One SSE subscription per turn, supervised as its own process group.
set -uo pipefail
source "$(dirname -- "$0")/shell_common.sh"
run=$1 sid=$2 url=$3 query=$4 request_id=$5
curl --config "$run/transport.curl" --silent --show-error --no-buffer --noproxy '*' \
    --connect-timeout 3 --max-time 610 "$url/event?directory=$query" 2>>"$run/event_stream.log" |
while IFS= read -r line; do
    case "$line" in
        'data: '*)
            [[ -f "$run/stream.ready" ]] || printf 'ready\n' >"$run/stream.ready"
            printf '%s\n' "${line#data: }" ;;
    esac
done |
"$JQ" --unbuffered -nc --arg sid "$sid" --arg request_id "$request_id" -f "$ROOT/event_reduce.jq" |
while IFS= read -r frame; do
    printf '%s\n' "$frame" >"$run/stream_current.json.tmp"
    mv -f -- "$run/stream_current.json.tmp" "$run/stream_current.json"
    printf '%s\n' "$frame" >>"$run/stream_frames.jsonl"
done

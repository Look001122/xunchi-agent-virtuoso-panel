# Isolated per-panel config. Existing installed launcher supplies the connection.
{"$schema":"https://opencode.ai/config.json",
 share:"disabled", snapshot:false, autoupdate:false, formatter:false, lsp:false,
 default_agent:"virtuoso",
 permission:{"*":"allow",task:"deny",question:"deny"},
 experimental:{mcp_timeout:300000},
 agent:{virtuoso:{mode:"primary",description:"Virtuoso authorized design operator",steps:32,
   permission:{"*":"allow",task:"deny",question:"deny"},prompt:$prompt}},
 mcp:{virtuoso:{type:"local",enabled:true,
   command:["/bin/bash",($root+"/virtuoso_mcp.sh"),"--run",$run]}}}

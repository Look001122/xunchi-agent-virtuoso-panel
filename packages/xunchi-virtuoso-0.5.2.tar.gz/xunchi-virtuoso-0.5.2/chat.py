# -*- coding: utf-8 -*-
"""Python2/Gtk3 Unicode chat UI inside an owned Virtuoso native dock."""
from __future__ import print_function, unicode_literals
import argparse
import io
import json
import os
import time
import uuid
import sys
os.environ.setdefault('GTK_IM_MODULE', 'ibus')
import gi
gi.require_version('Gtk', '3.0')
gi.require_version('GdkX11', '3.0')
from gi.repository import Gtk, Gdk, GdkX11, GLib, Pango
from x11 import X11
try:
    from markdown_view import MarkdownRenderer
    from transcript_scroll import TranscriptScroll
    from operation_view import selection_text
except ImportError:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'plugin'))
    from markdown_view import MarkdownRenderer
    from transcript_scroll import TranscriptScroll
    from operation_view import selection_text


def save_json(path, data):
    temporary = path + '.tmp-' + str(os.getpid())
    text = json.dumps(data, ensure_ascii=False, indent=2)
    if isinstance(text, bytes):
        text = text.decode('utf-8')
    with io.open(temporary, 'w', encoding='utf-8') as stream:
        stream.write(text)
    os.rename(temporary, path)


def read_json(path, default=None):
    try:
        with io.open(path, encoding='utf-8') as stream:
            return json.load(stream)
    except IOError:
        return default


class Chat(object):
    def __init__(self, args):
        self.folder = args.run
        self.host = args.host
        self.agent_mode = not args.local_echo
        self.busy = False
        self.tool_executing = False
        self.backend_state = None
        self.agent_session_id = None
        self.meta = {}
        self.target_choices = None
        self.updating_targets = False
        self.binding_pending = None
        self.binding_started = 0
        self.stage = 'connecting' if self.agent_mode else 'offline'
        self.started_at = None
        self.rendering = False
        self.force_bottom = True
        self.layout_attempts = 0
        self.layout_last_attempt = 0
        self.layout_restored = False
        self.x = X11()
        if not self.x.attributes(self.host):
            raise RuntimeError('Native host no longer exists')
        self.preferences_path = os.path.join(os.path.dirname(self.folder), 'ui-preferences.json')
        self.initial_width = self.x.attributes(self.host).width
        self.entries = []
        history_path = os.path.join(self.folder, 'agent_history.json' if self.agent_mode else 'roundtrip.json')
        if os.path.isfile(history_path):
            with io.open(history_path, encoding='utf-8') as stream:
                self.entries = json.load(stream)['entries'][-40:]
        self.last_geometry = None
        self.last_context = ''
        self.host_visible = False
        self.stopped = False
        self.active = False
        self.composing = False
        # Gtk.Plug tracks a foreign X11 parent, unlike a reparented toplevel.
        # This host is not Gtk.Socket; input focus is explicitly handled below.
        self.window = Gtk.Plug.new(self.host)
        self.window.set_title('XunChi Unicode child')
        self.window.set_default_size(600, 640)
        self.window.set_accept_focus(True)
        self.window.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.window.connect('button-press-event', self.focus)
        self.window.connect('destroy', self.destroyed)
        css = Gtk.CssProvider()
        css.load_from_data(b'#xc_panel {background-color:#f5f7fb;} #xc_title {font-weight:bold;font-size:14px;color:#243d5b;} button {padding:4px 9px;} textview {font-family:sans;font-size:13px;} #xc_status {color:#52647a;font-size:12px;}')
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        column = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        column.set_name('xc_panel')
        column.set_border_width(12)
        self.window.add(column)
        header = Gtk.Box(spacing=6)
        heading = Gtk.Label(label='XunChi Agent' if self.agent_mode else 'XunChi Agent · 离线验证')
        heading.set_name('xc_title')
        heading.set_xalign(0)
        header.pack_start(heading, True, True, 0)
        copy = Gtk.Button(label='复制回答')
        copy.connect('clicked', self.copy_answer)
        clear = Gtk.Button(label='清空显示')
        self.clear_button = clear
        clear.connect('clicked', self.clear)
        latest = Gtk.Button(label='最新')
        self.latest_button = latest
        latest.connect('clicked', lambda *unused: self.scroll_end())
        header.pack_start(latest, False, False, 0)
        header.pack_start(copy, False, False, 0)
        header.pack_start(clear, False, False, 0)
        column.pack_start(header, False, False, 0)
        target_row = Gtk.Box(spacing=6)
        self.target_combo = Gtk.ComboBoxText()
        self.target_combo.set_hexpand(True)
        for cell in self.target_combo.get_cells():
            cell.set_property('ellipsize', Pango.EllipsizeMode.MIDDLE)
            cell.set_property('width-chars', 28)
        self.target_combo.connect('changed', self.target_changed)
        self.target_combo.set_tooltip_text('选择要关联的设计窗口；面板焦点变化不会自动改绑')
        self.bind_button = Gtk.Button(label='关联当前')
        self.bind_button.connect('clicked', self.bind_current)
        target_row.pack_start(self.target_combo, True, True, 0)
        target_row.pack_start(self.bind_button, False, False, 0)
        column.pack_start(target_row, False, False, 0)
        self.context = Gtk.Label(label='正在读取关联设计…')
        self.context.set_xalign(0)
        self.context.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
        column.pack_start(self.context, False, False, 0)
        self.selection_preview = Gtk.Label(label='正在读取选择…')
        self.selection_preview.set_xalign(0)
        self.selection_preview.set_line_wrap(True)
        self.selection_preview.set_max_width_chars(70)
        column.pack_start(self.selection_preview, False, False, 0)
        self.transcript = Gtk.TextView()
        self.transcript.set_editable(False)
        self.transcript.set_cursor_visible(False)
        self.transcript.set_left_margin(12)
        self.transcript.set_right_margin(12)
        self.transcript.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.renderer = MarkdownRenderer(self.transcript)
        self.transcript.connect('populate-popup', self.code_menu)
        self.history_scroll = self.scrolled(self.transcript)
        self.history_scroll.set_size_request(-1, 120)
        self.scrolling = TranscriptScroll(self.transcript, self.history_scroll, self.follow_changed)
        self.split = Gtk.Paned(orientation=Gtk.Orientation.VERTICAL)
        self.split.set_wide_handle(True)
        self.split.pack1(self.history_scroll, True, False)
        composer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.split.pack2(composer, False, False)
        column.pack_start(self.split, True, True, 0)
        prompt = Gtk.Label(label='Enter 发送 · Shift+Enter 换行')
        prompt.set_xalign(0)
        composer.pack_start(prompt, False, False, 0)
        self.input = Gtk.TextView()
        self.input.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.input.connect('button-press-event', self.focus)
        self.input.connect('key-press-event', self.key)
        self.input.connect('preedit-changed', self.preedit_changed)
        self.input.get_buffer().connect('changed', self.draft_changed)
        saved_draft = read_json(os.path.join(self.folder, 'draft.json'), {})
        if saved_draft.get('text'):
            self.input.get_buffer().set_text(saved_draft['text'])
        input_scroll = self.scrolled(self.input)
        input_scroll.set_size_request(-1, 76)
        composer.pack_start(input_scroll, True, True, 0)
        buttons = Gtk.Box(spacing=8)
        send = Gtk.Button(label='发送')
        self.send_button = send
        send.get_style_context().add_class('suggested-action')
        send.connect('clicked', self.send)
        buttons.pack_start(send, False, False, 0)
        self.cancel_button = Gtk.Button(label='停止')
        self.cancel_button.connect('clicked', self.cancel)
        self.reconnect_button = Gtk.Button(label='重连')
        self.reconnect_button.connect('clicked', self.reconnect)
        self.retry_button = Gtk.Button(label='重试')
        self.retry_button.connect('clicked', self.retry)
        if self.agent_mode:
            buttons.pack_start(self.cancel_button, False, False, 0)
            buttons.pack_start(self.retry_button, False, False, 0)
            buttons.pack_start(self.reconnect_button, False, False, 0)
        composer.pack_start(buttons, False, False, 0)
        status_row = Gtk.Box(spacing=6)
        self.spinner = Gtk.Spinner()
        status_row.pack_start(self.spinner, False, False, 0)
        self.status = Gtk.Label(label='正在连接 Agent 服务…' if self.agent_mode else '本地回显验证 · 未连接 LLM')
        self.status.set_name('xc_status')
        self.status.set_xalign(0)
        self.status.set_line_wrap(True)
        status_row.pack_start(self.status, True, True, 0)
        self.elapsed = Gtk.Label(label='')
        status_row.pack_start(self.elapsed, False, False, 0)
        column.pack_start(status_row, False, False, 0)
        self.window.realize()
        self.child = GdkX11.X11Window.get_xid(self.window.get_window())
        self.render()
        self.window.show_all()
        self.split.set_position(max(150, self.x.attributes(self.host).height - 330))
        self.x.x.XMapWindow(self.x.display, self.child)
        self.x.x.XSync(self.x.display, 0)
        self.x.xembed(self.child, 0, self.host)  # EMBEDDED_NOTIFY
        self.input.grab_focus()
        if self.agent_mode:
            for name in ('requests', 'responses'):
                path = os.path.join(self.folder, name)
                if not os.path.isdir(path):
                    try:
                        os.makedirs(path, 0o700)
                    except OSError:
                        if not os.path.isdir(path):
                            raise
        self.tick()
        self.event('embedded', host=self.host, child=self.child)
        GLib.timeout_add(200, self.tick)

    @staticmethod
    def scrolled(widget):
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.add(widget)
        return scroll

    def event(self, kind, **values):
        values.update(event=kind, time=time.time())
        with io.open(os.path.join(self.folder, 'ui_events.jsonl'), 'a', encoding='utf-8') as stream:
            stream.write(json.dumps(values, ensure_ascii=False) + '\n')

    def text(self, view):
        buffer_ = view.get_buffer()
        text = buffer_.get_text(buffer_.get_start_iter(), buffer_.get_end_iter(), True)
        return text.decode('utf-8') if isinstance(text, bytes) else text

    def focus(self, widget, event):
        self.x.focus(self.child)
        self.update_focus()
        return False

    def update_focus(self):
        active = self.x.focused_within(self.child)
        if active != self.active:
            self.active = active
            self.x.xembed(self.child, 1 if active else 2)  # WINDOW_ACTIVATE/DEACTIVATE
            self.x.xembed(self.child, 4 if active else 5)  # FOCUS_IN/OUT
            self.event('focus', active=active)

    def key(self, widget, event):
        if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            # The IM gets Return while composing; never send an unfinished word.
            if self.composing or event.state & Gdk.ModifierType.SHIFT_MASK:
                return False
            self.send()
            return True
        return False

    def preedit_changed(self, widget, text):
        self.composing = bool(text)

    def draft_changed(self, buffer_):
        save_json(os.path.join(self.folder, 'draft.json'), {'text': self.text(self.input)})

    def send(self, *unused):
        if self.agent_mode and self.busy:
            self.status.set_text('正在回答，请等待完成或点击停止')
            return
        if not self.meta.get('valid', False):
            self.status.set_text('请先选择一个仍然打开的关联设计')
            return
        text = self.text(self.input)
        if not text.strip():
            self.status.set_text('请输入内容')
            return
        if len(text.encode('utf-8')) > 12000:
            self.status.set_text('单条输入最多 12000 字节')
            return
        if self.agent_mode:
            backend = read_json(os.path.join(self.folder, 'agent_state.json'), {})
            if backend.get('state') == 'failed':
                self.status.set_text('Agent 连接失败，请点击重连')
                return
            ident = uuid.uuid4().hex
            meta = read_json(os.path.join(self.folder, 'context_meta.json'), {})
            sequence = self.entries[-1]['id'] + 1 if self.entries else 1
            entry = {'id': sequence, 'request_id': ident, 'input': text, 'answer': '',
                     'state': 'queued', 'phase': 'waiting', 'mode': 'agent_design',
                     'target_token': meta.get('target_token'), 'target_label': meta.get('label'),
                     'selection_at_send': {'selection_token': meta.get('selection_token'),
                         'selected_count': meta.get('selected_count', 0), 'selected_objects': meta.get('selected_objects', [])}}
            self.entries.append(entry)
            self.entries = self.entries[-40:]
            self.busy = True
            self.started_at = time.time()
            self.force_bottom = True
            self.save_history()
            save_json(os.path.join(self.folder, 'requests', ident + '.json'),
                       {'request_id': ident, 'text': text, 'target_token': meta.get('target_token'),
                        'selection_token': meta.get('selection_token')})
            self.input.get_buffer().set_text('')
            self.status.set_text('已发送，等待 Agent 回答…')
            self.render()
            self.input.grab_focus()
            self.send_button.set_sensitive(False)
            self.event('agent_send', request_id=ident)
            return
        sequence = self.entries[-1]['id'] + 1 if self.entries else 1
        entry = {'id': sequence, 'input': text, 'echo': text,
                 'context': self.last_context, 'mode': 'local_echo_no_llm'}
        self.entries.append(entry)
        self.entries = self.entries[-40:]
        self.force_bottom = True
        self.render()
        # Capture the actual Gtk transcript value, not only the source string.
        save_json(os.path.join(self.folder, 'roundtrip.json'),
                  {'entries': self.entries, 'transcript': self.text(self.transcript)})
        self.input.get_buffer().set_text('')
        self.status.set_text('中文回显完成 · 未连接 LLM')
        self.input.grab_focus()
        self.event('send', input=text, echo=entry['echo'])

    def render(self):
        if self.force_bottom:
            self.scrolling.set_follow(True)
            self.force_bottom = False
        self.scrolling.before_update()
        self.rendering = True
        try:
            changed = self.renderer.render(self.entries, self.agent_mode)
        finally:
            self.rendering = False
        self.scrolling.after_update(changed)

    def scroll_end(self):
        return self.scrolling.latest()

    def follow_changed(self, following):
        self.latest_button.set_tooltip_text('正在跟随新回答' if following else '已暂停跟随，点击回到最新内容')
        context = self.latest_button.get_style_context()
        if following:
            context.remove_class('suggested-action')
        else:
            context.add_class('suggested-action')

    def clear(self, *unused):
        if self.busy:
            self.status.set_text('请先等待当前回答完成或停止')
            return
        self.entries = []
        self.force_bottom = True
        self.render()
        if self.agent_mode:
            self.save_history()
            self.status.set_text('已清空显示，Agent 会话继续保留')
        else:
            save_json(os.path.join(self.folder, 'roundtrip.json'), {'entries': [], 'transcript': ''})

    def save_history(self):
        save_json(os.path.join(self.folder, 'agent_history.json'),
                  {'entries': self.entries, 'session_id': self.agent_session_id})

    def cancel(self, *unused):
        pending = next((e for e in self.entries if e.get('state') in ('queued', 'running', 'cancelling')), None)
        if pending:
            pending['cancel_requested'] = True
            pending['state'] = 'cancelling'
            self.save_history()
            self.render()
            save_json(os.path.join(self.folder, 'cancel.request'), {'request_id': pending['request_id']})
            self.status.set_text('正在停止…')

    def reconnect(self, *unused):
        if not self.busy:
            save_json(os.path.join(self.folder, 'restart_agent.request'), {})
            self.status.set_text('正在重新连接 Agent…')

    def retry(self, *unused):
        if self.busy or not self.entries:
            return
        if os.path.exists(os.path.join(self.folder, 'tool.executing')):
            self.status.set_text('SKILL 操作仍在执行，完成后先核对设计状态再重试')
            return
        last = self.entries[-1]
        if last.get('state') not in ('failed', 'cancelled'):
            return
        self.input.get_buffer().set_text(last['input'])
        if last.get('target_token') != self.meta.get('target_token'):
            self.status.set_text('关联设计已变化，原问题已放回输入框，请确认后发送')
            return
        frozen = last.get('context_snapshot') or last.get('selection_at_send', {})
        if frozen.get('selection_token') != self.meta.get('selection_token'):
            self.status.set_text('选中对象已变化，原问题已放回输入框，请核对后重新发送')
            return
        if self.backend_state == 'failed':
            self.status.set_text('原问题已放回输入框，请先重连再发送')
            return
        self.send()

    def copy_answer(self, *unused):
        if self.entries:
            text = self.entries[-1].get('answer', self.entries[-1].get('echo', ''))
            Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(text, -1)

    def code_menu(self, view, menu):
        for index, code in enumerate(self.renderer.codes[-12:]):
            item = Gtk.MenuItem(label='复制代码块 {}'.format(index + 1))
            item.connect('activate', lambda widget, text=code: Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).set_text(text, -1))
            menu.append(item)
            item.show()

    def target_changed(self, combo):
        if not self.updating_targets and not self.busy:
            ident = combo.get_active_id()
            if ident:
                self.request_binding(ident)

    def bind_current(self, *unused):
        if not self.busy:
            self.request_binding('current')

    def request_binding(self, ident):
        self.binding_pending = ident
        self.binding_started = time.time()
        with io.open(os.path.join(self.folder, 'bind.request.tmp'), 'w', encoding='utf-8') as stream:
            stream.write(ident + '\n')
        os.rename(os.path.join(self.folder, 'bind.request.tmp'), os.path.join(self.folder, 'bind.request'))
        self.status.set_text('正在关联设计窗口…')

    def poll_target(self):
        meta = read_json(os.path.join(self.folder, 'context_meta.json'), {})
        choices = [(w['window_id'], w['label']) for w in meta.get('windows', [])]
        self.updating_targets = True
        if choices != self.target_choices:
            self.target_combo.remove_all()
            for ident, label in choices:
                self.target_combo.append(ident, label)
            self.target_choices = choices
        if not self.binding_pending or self.binding_pending == meta.get('target_window'):
            self.target_combo.set_active_id(meta.get('target_window', ''))
        self.updating_targets = False
        self.meta = meta
        self.selection_preview.set_text('当前选择：' + selection_text(meta).replace('发送时选择 ', '', 1))
        self.selection_preview.set_tooltip_text(selection_text(meta))
        self.target_combo.set_sensitive(not self.busy)
        self.bind_button.set_sensitive(not self.busy)
        self.send_button.set_sensitive(not self.busy and meta.get('valid', False))
        if not meta.get('valid'):
            self.context.set_text('关联窗口已关闭，请选择另一个设计后发送')
        else:
            self.context.set_text('固定关联 {} · 已选 {} 个对象'.format(meta['target_window'], meta.get('selected_count', 0)))
        self.context.set_tooltip_text(meta.get('label', ''))
        if self.binding_pending:
            requested = self.binding_pending
            consumed = not os.path.exists(os.path.join(self.folder, 'bind.request'))
            matched = meta.get('valid') and meta.get('target_window') == requested
            current_done = requested == 'current' and consumed and time.time() - self.binding_started > .7
            if matched or current_done:
                self.binding_pending = None
                self.status.set_text('已关联：' + meta.get('label', ''))
            elif consumed and time.time() - self.binding_started > 2:
                self.binding_pending = None
                self.status.set_text('关联未完成，请重新选择仍然打开的设计窗口')

    def poll_agent(self):
        backend = read_json(os.path.join(self.folder, 'agent_state.json'), {'state': 'starting'})
        state = backend.get('state')
        tool_executing = os.path.exists(os.path.join(self.folder, 'tool.executing'))
        execution_finished = self.tool_executing and not tool_executing
        self.tool_executing = tool_executing
        self.agent_session_id = backend.get('session_id')
        changed = False
        frame = read_json(os.path.join(self.folder, 'stream_current.json'), {})
        for entry in self.entries:
            if entry.get('state') not in ('queued', 'running', 'cancelling'):
                continue
            response = read_json(os.path.join(self.folder, 'responses', entry['request_id'] + '.json'), {})
            if response.get('request_id') == entry['request_id']:
                for key in ('state', 'answer', 'error', 'session_id', 'tools', 'context_snapshot', 'operation_summary', 'not_dispatched'):
                    if key == 'state' and entry.get('cancel_requested') and response.get(key) in ('running', 'queued'):
                        continue
                    if key in response and entry.get(key) != response[key]:
                        entry[key] = response[key]
                        changed = True
            if (entry.get('state') == 'running' and frame.get('request_id') == entry['request_id']
                    and frame.get('revision') != entry.get('stream_revision')):
                entry.update(answer=frame.get('answer', ''), phase=frame.get('phase', 'waiting'),
                             stream_revision=frame.get('revision'))
                changed = True
            if state == 'failed' and entry.get('state') in ('queued', 'running', 'cancelling'):
                entry.update(state='failed', error=backend.get('error', {'message': 'Agent 服务已断开'}))
                changed = True
        self.busy = any(e.get('state') in ('queued', 'running', 'cancelling') for e in self.entries)
        if changed:
            self.save_history()
            self.render()
        # The native operation can outlive the Agent request. Its marker may
        # disappear without a response or backend update, so restore the status
        # on that transition too, without overwriting later UI messages.
        if self.entries and (changed or (execution_finished and state == 'ready')):
            last = self.entries[-1]
            self.status.set_text({'queued': '等待 Agent 服务…', 'running': 'Agent 正在回答…',
                'completed': '回答完成', 'failed': '请求失败，可重试或重连', 'cancelled': '已停止',
                'cancelling': '正在停止…'}.get(last.get('state'), ''))
            if last.get('state') == 'failed' and last.get('error', {}).get('code') in ('SELECTION_CHANGED', 'TARGET_CHANGED'):
                self.status.set_text('设计或选中对象已变化，本次未继续执行；请核对后重新发送')
        elif (state != self.backend_state or execution_finished) and not self.busy:
            if state == 'ready':
                self.status.set_text('已连接 Agent · 全部设计操作已授权')
            elif state == 'failed':
                self.status.set_text('连接失败：' + backend.get('error', {}).get('message', '请点击重连'))
            else:
                self.status.set_text('正在连接 Agent 服务…')
        progress = read_json(os.path.join(self.folder, 'tool_progress.json'), {})
        if self.busy and self.entries:
            phase = 'cancelling' if self.entries[-1].get('state') == 'cancelling' else self.entries[-1].get('phase', 'waiting')
            self.stage = phase
            self.status.set_text({'waiting': '等待模型响应…', 'thinking': '模型处理中…', 'tool': '正在调用设计工具…',
                                  'answering': '正在生成回答…', 'cancelling': '正在停止…'}.get(phase, '正在回答…'))
        else:
            self.stage = self.entries[-1].get('state', 'ready') if self.entries else state
        if self.busy and self.entries and progress.get('request_id') == self.entries[-1].get('request_id') and progress.get('state') == 'running':
            self.status.set_text('正在执行 SKILL 设计操作…' if progress.get('operation') == 'execute_skill' else '正在查询当前 Virtuoso 设计…')
        if not self.busy and tool_executing:
            cancelled = self.entries and (self.entries[-1].get('state') == 'cancelled'
                                         or self.entries[-1].get('cancel_requested'))
            self.status.set_text('SKILL 操作仍在执行；停止只取消了 Agent 等待' if cancelled
                                 else 'SKILL 操作仍在执行，完成后请核对设计状态')
        self.backend_state = state
        self.send_button.set_sensitive(not self.busy and state != 'failed' and self.meta.get('valid', False))
        self.clear_button.set_sensitive(not self.busy)
        self.cancel_button.set_sensitive(self.busy)
        self.reconnect_button.set_sensitive(not self.busy)
        self.retry_button.set_sensitive(not self.busy and self.meta.get('valid', False) and bool(self.entries) and self.entries[-1].get('state') in ('failed', 'cancelled'))
        if self.busy or state == 'starting':
            self.spinner.start()
        else:
            self.spinner.stop()
        self.elapsed.set_text('{}s'.format(int(time.time() - self.started_at)) if self.busy and self.started_at else '')

    def tick(self):
        if self.stopped:
            return False
        attributes = self.x.attributes(self.host)
        if not attributes:
            self.stop('host_destroyed')
            return False
        # IC618 may ignore dock hints after the first map. Restore a usable
        # width on activation only, retaining the pointer and input focus.
        if (attributes.width < 360 and self.layout_attempts < 2 and
                time.time() - self.layout_last_attempt > 1 and
                os.environ.get('XUNCHI_VIRTUOSO_NO_AUTO_SIZE') != '1'):
            preferred = read_json(self.preferences_path, {}).get('width', 600)
            preferred = max(360, min(900, int(preferred)))
            fitted = self.x.fit_dock(self.host, preferred)
            if fitted is not None:
                self.layout_last_attempt = time.time()
                self.layout_attempts += 1
                self.layout_restored = bool(fitted)
                self.active = False
                self.update_focus()
                attributes = self.x.attributes(self.host)
        visible = attributes.map_state == 2
        geometry = (attributes.width, attributes.height)
        child_now = self.x.attributes(self.child)
        expected = (max(1, geometry[0]), max(1, geometry[1] - 24))
        drifted = child_now and ((child_now.width, child_now.height) != expected or
                   (self.window.get_allocated_width(), self.window.get_allocated_height()) != expected)
        if geometry != self.last_geometry or drifted:
            allocation = Gdk.Rectangle()
            allocation.x = 0
            allocation.y = 0
            allocation.width = max(1, geometry[0])
            allocation.height = max(1, geometry[1] - 24)
            # Gtk may revisit its default size after a status/layout change.
            self.window.set_default_size(allocation.width, allocation.height)
            self.window.size_allocate(allocation)
            self.window.get_window().move_resize(0, 24, allocation.width, allocation.height)
            self.window.queue_draw()
            Gdk.Display.get_default().sync()
            self.last_geometry = geometry
            if 350 <= geometry[0] <= 1000:
                save_json(self.preferences_path, {'width': geometry[0]})
            self.event('resize', width=geometry[0], height=geometry[1] - 24)
        if visible != self.host_visible:
            self.host_visible = visible
            self.event('visibility', visible=visible)
        self.update_focus()
        self.poll_target()
        if self.agent_mode:
            self.poll_agent()
        path = os.path.join(self.folder, 'context.txt')
        try:
            with io.open(path, encoding='utf-8') as stream:
                context = stream.read().strip()
            if context != self.last_context and len(context.splitlines()) == 4:
                self.last_context = context
                lib, cell, view, count = context.splitlines()
        except IOError:
            pass
        child_attributes = self.x.attributes(self.child)
        save_json(os.path.join(self.folder, 'ui_state.json'),
                  {'host': self.host, 'child': self.child, 'visible': visible,
                   'pid': os.getpid(),
                   'host_geometry': list(geometry), 'child_parent': self.x.children(self.child)[0],
                   'child_geometry': [child_attributes.width, child_attributes.height] if child_attributes else None,
                   'child_map_state': child_attributes.map_state if child_attributes else None,
                   'gtk_allocation': [self.window.get_allocated_width(), self.window.get_allocated_height()],
                   'input_has_focus': self.input.has_focus(),
                   'composing': self.composing,
                   'keyboard': 'enter_send_shift_enter_newline',
                   'gtk_toplevel_focus': self.window.has_toplevel_focus(),
                   'input_rect': self.widget_rect(self.input),
                   'send_rect': self.widget_rect(self.send_button),
                   'cancel_rect': self.widget_rect(self.cancel_button) if self.agent_mode else None,
                   'reconnect_rect': self.widget_rect(self.reconnect_button) if self.agent_mode else None,
                   'retry_rect': self.widget_rect(self.retry_button) if self.agent_mode else None,
                   'target_combo_rect': self.widget_rect(self.target_combo), 'bind_rect': self.widget_rect(self.bind_button),
                   'split_rect': self.widget_rect(self.split), 'split_position': self.split.get_position(),
                   'split_handle_rect': self.handle_rect(),
                   'entries': len(self.entries), 'context': self.last_context,
                   'busy': self.busy, 'backend_state': self.backend_state,
                   'agent_session_id': self.agent_session_id,
                   'ui_version': '0.5.1', 'permissions': 'design_full', 'target_valid': self.meta.get('valid', False),
                   'selection_token': self.meta.get('selection_token'),
                   'selection_preview': selection_text(self.meta),
                   'send_enabled': self.send_button.get_sensitive(),
                   'target_notice': self.context.get_text().decode('utf-8') if isinstance(self.context.get_text(), bytes) else self.context.get_text(),
                   'initial_native_width': self.initial_width,
                   'layout_restored': self.layout_restored,
                   'target_window': self.meta.get('target_window'), 'target_choices': self.meta.get('windows', []),
                   'stage': self.stage, 'status_text': self.status.get_text().decode('utf-8') if isinstance(self.status.get_text(), bytes) else self.status.get_text(),
                   'markdown': self.renderer.stats,
                   'scroll': self.scrolling.snapshot(), 'renderer_update': self.renderer.last_update,
                   'draft_characters': len(self.text(self.input)),
                   'latest_rect': self.widget_rect(self.latest_button), 'transcript_rect': self.widget_rect(self.transcript),
                   'mode': 'agent_design' if self.agent_mode else 'local_echo_no_llm'})
        return True

    def widget_rect(self, widget):
        allocation = widget.get_allocation()
        position = widget.translate_coordinates(self.window, 0, 0)
        return [position[0], position[1], allocation.width, allocation.height] if position else None

    def handle_rect(self):
        handle = self.split.get_handle_window()
        if not handle:
            return None
        origin = handle.get_origin()[-2:]
        root = self.x.root_coordinates(self.child)
        geometry = handle.get_geometry()
        return [origin[0] - root[0], origin[1] - root[1], geometry[-2], geometry[-1]]

    def stop(self, reason):
        if not self.stopped:
            self.stopped = True
            self.event(reason)
            save_json(os.path.join(self.folder, 'stopped.json'), {'reason': reason})
            Gtk.main_quit()

    def destroyed(self, *unused):
        self.stop('child_destroyed')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', type=int, required=True)
    parser.add_argument('--run', required=True)
    parser.add_argument('--local-echo', action='store_true', help='Explicit offline UI regression mode; no Agent service')
    args = parser.parse_args()
    chat = Chat(args)
    Gtk.main()


if __name__ == '__main__':
    main()

; Selection epochs bind a turn to actual OA identities, not just object names.
unless(boundp('xcV05SelectionKey) xcV05SelectionKey="")
unless(boundp('xcV05SelectionEpoch) xcV05SelectionEpoch=0)
unless(boundp('xcV05SelectionToken) xcV05SelectionToken="")
unless(boundp('xcV05BoundRequest) xcV05BoundRequest=nil)
unless(boundp('xcV05BoundIds) xcV05BoundIds=nil)

procedure(xcV05Selection()
 let((objects ids key)
  objects=if(xcU12CellView(xcU12Target) then geGetSelSet(xcU12Target) else nil)
  objects=setof(obj objects dbIsId(obj))
  ids=foreach(mapcar obj objects sprintf(nil "%L" obj))
  ids=sort(ids 'alphalessp)
  key=strcat(xcV02TargetToken "|" buildString(ids ";"))
  unless(key==xcV05SelectionKey
   xcV05SelectionEpoch=xcV05SelectionEpoch+1 xcV05SelectionKey=key)
  xcV05SelectionToken=sprintf(nil "%d:%d:%d" ipcGetPid() xcU12Epoch xcV05SelectionEpoch)
  list(objects ids)
 ))

procedure(xcV05ObjectsJSON(objects maximum)
 let((rows n name)
  rows="" n=0
  foreach(obj objects
   when(n<maximum
    name=obj~>name
    rows=strcat(rows if(n>0 then "," else "")
     sprintf(nil "{\"object_id\":%s,\"object_type\":%s,\"name\":%s,\"layer\":%s}"
      xcV02Json(sprintf(nil "%L" obj)) xcV02Json(obj~>objType) xcV02Json(name) xcV02Json(obj~>layerName))))
   n=n+1)
  strcat("[" rows "]")
 ))

procedure(xcV05Fields(obj)
 let((fields props)
  fields=list(
   list("name" sprintf(nil "%L" obj~>name))
   list("label_text" sprintf(nil "%L" obj~>theLabel))
   list("bbox" sprintf(nil "%L" obj~>bBox))
   list("layer" sprintf(nil "%L" obj~>layerName))
   list("purpose" sprintf(nil "%L" obj~>purpose))
   list("width" sprintf(nil "%L" obj~>width))
   list("points" sprintf(nil "%L" obj~>points))
   list("begin_point" sprintf(nil "%L" obj~>beginPt))
   list("end_point" sprintf(nil "%L" obj~>endPt))
   list("origin" sprintf(nil "%L" obj~>xy))
   list("orientation" sprintf(nil "%L" obj~>orient)))
  when(obj~>objType=="inst" && obj~>master
   fields=cons(list("master" sprintf(nil "%s/%s/%s %L" obj~>master~>libName obj~>master~>cellName obj~>master~>viewName obj~>master)) fields)
   fields=cons(list("pcell_parameters" sprintf(nil "%L" obj~>master~>parameters)) fields))
  foreach(prop obj~>prop
   when(prop~>name fields=cons(list(strcat("property:" prop~>name) sprintf(nil "%L" prop~>value)) fields)))
  fields
 ))

procedure(xcV05State(cv)
 let((objects table ids selected n id)
  selected=xcV05BoundIds
  objects=append(cv~>instances append(cv~>shapes cv~>vias))
  table=makeTable('xcV05State nil) ids=nil n=0
  foreach(obj objects
   when(n<5000
    id=sprintf(nil "%L" obj)
    table[id]=list(id obj~>objType obj~>name member(id selected) xcV05Fields(obj))
    ids=cons(id ids))
   n=n+1)
  list(table ids n n>5000)
 ))

procedure(xcV05FieldChanges(before after)
 let((rows other n)
  rows="" n=0
  foreach(pair before
   other=assoc(car(pair) after)
   unless(other && equal(cadr(pair) cadr(other))
    rows=strcat(rows if(n>0 then "," else "") sprintf(nil "{\"field\":%s,\"before\":%s,\"after\":%s}"
     xcV02Json(car(pair)) xcV02Json(cadr(pair)) xcV02Json(when(other cadr(other)))))
    n=n+1))
  foreach(pair after
   unless(assoc(car(pair) before)
    rows=strcat(rows if(n>0 then "," else "") sprintf(nil "{\"field\":%s,\"before\":null,\"after\":%s}"
     xcV02Json(car(pair)) xcV02Json(cadr(pair)))) n=n+1))
  list(rows n)
 ))

procedure(xcV05Diff(before after)
 let((old new ids created deleted modified outside details n left right status fields record)
  if(nth(3 before) || nth(3 after) then
   sprintf(nil "{\"available\":false,\"reason\":\"SCAN_LIMIT\",\"scope\":\"associated_cellview_top_level\",\"before_total\":%d,\"after_total\":%d,\"note\":\"More than 5000 top-level objects; use task-specific verification rather than infer creation/deletion from a partial scan\"}" nth(2 before) nth(2 after))
   else
  old=car(before) new=car(after)
  ids=append(cadr(before) setof(id cadr(after) !old[id]))
  created=0 deleted=0 modified=0 outside=0 details="" n=0
  foreach(id ids
   left=old[id] right=new[id] status=nil fields=list("" 0)
   cond(
    (!left created=created+1 status="created")
    (!right deleted=deleted+1 status="deleted")
    (t fields=xcV05FieldChanges(nth(4 left) nth(4 right))
     when(cadr(fields)>0 modified=modified+1 status="modified")))
   when(status
    record=if(right then right else left)
    unless(left && nth(3 left) outside=outside+1)
    when(n<40
     details=strcat(details if(n>0 then "," else "")
      sprintf(nil "{\"object_id\":%s,\"object_type\":%s,\"name\":%s,\"status\":%s,\"was_selected\":%s,\"fields\":[%s]}"
       xcV02Json(id) xcV02Json(nth(1 record)) xcV02Json(nth(2 record)) xcV02Json(status)
       if(left && nth(3 left) then "true" else "false") car(fields))))
    n=n+1))
  sprintf(nil "{\"available\":true,\"scope\":\"associated_cellview_top_level\",\"created\":%d,\"modified\":%d,\"deleted\":%d,\"outside_initial_selection\":%d,\"objects\":[%s],\"details_truncated\":%s,\"scan_truncated\":%s,\"before_total\":%d,\"after_total\":%d,\"note\":\"Observed fields only; hierarchy internals, other views, Shell and later async effects are not a full design diff.\"}"
   created modified deleted outside details if(n>40 then "true" else "false")
   if(nth(3 before) || nth(3 after) then "true" else "false") nth(2 before) nth(2 after))
  )
 ))

procedure(xcV05Capture(requestId targetToken selectionToken uiRequest)
 let((cv)
  cv=xcU12CellView(xcU12Target) xcV02Meta(cv)
  cond(
   (targetToken!=xcV02TargetToken || !cv xcV02Snapshot(requestId targetToken))
   (selectionToken!=xcV05SelectionToken
    sprintf(nil "{\"ok\":false,\"request_id\":%s,\"error\":{\"code\":\"SELECTION_CHANGED\",\"message\":\"Selection changed since the displayed send snapshot; review the selection and send again\"}}" xcV02Json(requestId)))
   (t
    xcV05BoundRequest=uiRequest
    xcV05BoundIds=cadr(xcV05Selection())
    xcV02Snapshot(requestId targetToken)))
 ))

"""User-level Virtuoso plugin installer, Python 3.6+, standard library only."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import tarfile
import tempfile

SOURCE = Path(__file__).resolve().parent
BEGIN = b'; BEGIN XUNCHI VIRTUOSO PLUGIN'
END = b'; END XUNCHI VIRTUOSO PLUGIN'
VERSION = '0.5.2'
FILES = {'host.il', 'design_tools.il', 'plugin.il', 'bridge.py', 'chat.py', 'x11.py',
         'panel_session.sh', 'shell_common.sh', 'agent_service.sh', 'virtuoso_mcp.sh',
         'agent-config.jq', 'agent-prompt.txt', 'tool-schema.json', 'jq-linux-amd64',
         'markdown_view.py', 'transcript_scroll.py', 'operation_view.py', 'stream_events.sh', 'event_reduce.jq', 'execute-skill-schema.json', 'selection_summary.il', 'result_summary.jq',
         'JQ_COPYING', 'ONIGURUMA_COPYING', 'THIRD_PARTY.md', 'install.py', 'README.md', 'init.il'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def atomic_write(path, data, mode=0o600):
    fd, temporary = tempfile.mkstemp(prefix='.xunchi-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, str(path))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def backup(path):
    if path.exists():
        name = str(path) + '.xunchi-backup-' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        shutil.copy2(str(path), name)
        return name


def source_file(name):
    for path in (SOURCE / name, SOURCE.parent / 'unicode_probe' / name):
        if path.is_file():
            return path
    raise ValueError('Missing plugin file: ' + name)


def payload(root):
    # SKILL accepts quoted ASCII path strings; reject control/non-ASCII paths.
    text = str(root)
    if any(ord(c) > 127 for c in text):
        raise ValueError('This IC618 prototype requires an ASCII installation path')
    if any(ord(c) < 32 for c in text):
        raise ValueError('Control characters in installation path')
    init = 'xcPluginRoot={}\n'.format(json.dumps(str(root)))
    init += '\n'.join('load({})'.format(json.dumps(str(root / name)))
                      for name in ('host.il', 'design_tools.il', 'selection_summary.il', 'plugin.il')) + '\n'
    files = {name: source_file(name).read_bytes() for name in FILES - {'init.il'}}
    files['init.il'] = init.encode('ascii')
    return files


def managed_block(root):
    return (b'\n' + BEGIN + b'\n' +
            ('when(isFile({0}) errset(load({0}) t))\n'.format(
                json.dumps(str(root / 'init.il')))).encode('ascii') + END + b'\n')


def check_path(cdsinit):
    if cdsinit.is_symlink():
        raise ValueError('Use --cdsinit with the real target of this symlink: ' + str(cdsinit))
    if not cdsinit.parent.is_dir():
        raise ValueError('The .cdsinit parent directory does not exist')


def install(root, cdsinit, upgrade_from=None):
    check_path(cdsinit)
    files = payload(root)
    block = managed_block(root)
    original = cdsinit.read_bytes() if cdsinit.exists() else b''
    marker = root / 'manifest.json'
    if root.exists():
        if not marker.is_file():
            raise ValueError('Installation directory already exists without our manifest')
        state = json.loads(marker.read_text(encoding='utf-8'))
        if state['cdsinit'] != str(cdsinit):
            raise ValueError('Existing installation uses a different .cdsinit')
        for name, data in files.items():
            if not (root / name).is_file() or (root / name).read_bytes() != data:
                raise ValueError('Installed files differ; preserve/review them before reinstalling: ' + name)
        if original.count(BEGIN) != 1 or original.count(END) != 1 or block not in original:
            raise ValueError('Managed startup block changed or is missing')
        return {'state': 'already_installed', 'root': str(root), 'cdsinit': str(cdsinit)}
    updated = original + block
    existed = cdsinit.exists()
    if BEGIN in original or END in original:
        if upgrade_from is None:
            raise ValueError('A XunChi startup block exists; use --upgrade-from with its installed directory')
        previous = json.loads((upgrade_from / 'manifest.json').read_text(encoding='utf-8'))
        old_block = managed_block(upgrade_from)
        if (previous['cdsinit'] != str(cdsinit) or previous['block'].encode('ascii') != old_block
                or original.count(BEGIN) != 1 or original.count(END) != 1 or original.count(old_block) != 1):
            raise ValueError('Previous startup configuration changed; preserved for review')
        for name, expected in previous['files'].items():
            if Path(name).name != name:
                raise ValueError('Invalid previous manifest')
            old = upgrade_from / name
            if old.is_symlink() or not old.is_file() or digest(old.read_bytes()) != expected:
                raise ValueError('Previous installed file changed; preserved: ' + name)
        existed = previous['cdsinit_existed']
        updated = original.replace(old_block, block, 1)
    root.mkdir(parents=True)
    try:
        for name, data in files.items():
            atomic_write(root / name, data, 0o700 if name == 'jq-linux-amd64' else 0o600)
        saved = backup(cdsinit)
        state = {'version': VERSION, 'cdsinit': str(cdsinit),
                 'cdsinit_existed': existed, 'backup': saved,
                 'upgrade_from': str(upgrade_from) if upgrade_from else None,
                 'block': block.decode('ascii'),
                 'files': {name: digest(data) for name, data in files.items()}}
        atomic_write(marker, json.dumps(state, indent=2).encode('utf-8'))
        mode = cdsinit.stat().st_mode & 0o777 if cdsinit.exists() else 0o600
        atomic_write(cdsinit, updated, mode)
    except Exception:
        # Only this freshly created, private directory is rolled back.
        shutil.rmtree(str(root))
        raise
    return {'state': 'installed', 'root': str(root), 'cdsinit': str(cdsinit), 'backup': saved}


def uninstall(root):
    if not root.exists():
        return {'state': 'already_absent', 'root': str(root)}
    marker = root / 'manifest.json'
    state = json.loads(marker.read_text(encoding='utf-8'))
    cdsinit = Path(state['cdsinit'])
    check_path(cdsinit)
    # Preflight everything before changing startup configuration.
    names = set(state['files'])
    if names != FILES:
        raise ValueError('Unexpected manifest file list')
    if set(p.name for p in root.iterdir()) != names | {'manifest.json'}:
        raise ValueError('Installation has extra files; preserve/review them before uninstalling')
    for name, expected in state['files'].items():
        path = root / name
        if path.is_symlink() or not path.is_file() or digest(path.read_bytes()) != expected:
            raise ValueError('Installed file changed; preserved: ' + name)
    original = cdsinit.read_bytes()
    block = state['block'].encode('ascii')
    if original.count(BEGIN) != 1 or original.count(END) != 1 or original.count(block) != 1:
        raise ValueError('Managed startup block changed; preserved for review')
    remainder = original.replace(block, b'', 1)
    saved = backup(cdsinit)
    if not state['cdsinit_existed'] and not remainder:
        cdsinit.unlink()
    else:
        atomic_write(cdsinit, remainder, cdsinit.stat().st_mode & 0o777)
    for name in names:
        (root / name).unlink()
    marker.unlink()
    root.rmdir()
    return {'state': 'uninstalled', 'root': str(root), 'backup': saved,
            'note': 'Restart Virtuoso to unload menus in already-running sessions'}


def package(output):
    if output.exists():
        raise ValueError('Output already exists: ' + str(output))
    with tarfile.open(str(output), 'w:gz') as archive:
        for name in sorted(FILES - {'init.il'}):
            archive.add(str(source_file(name)), arcname='xunchi-virtuoso-' + VERSION + '/' + name)
    return {'state': 'packaged', 'path': str(output), 'sha256': digest(output.read_bytes())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('install', 'uninstall', 'package'))
    parser.add_argument('--root', type=Path, default=Path.home() / ('.local/share/xunchi-virtuoso/' + VERSION))
    parser.add_argument('--upgrade-from', type=Path, help='Replace the validated startup block of an earlier installation; keep its files')
    parser.add_argument('--cdsinit', type=Path, default=Path.home() / '.cdsinit')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        if args.action == 'package':
            if not args.output:
                parser.error('package requires --output')
            result = package(args.output.expanduser().absolute())
        elif args.action == 'install':
            result = install(args.root.expanduser().absolute(), args.cdsinit.expanduser().absolute(),
                             args.upgrade_from.expanduser().absolute() if args.upgrade_from else None)
        else:
            result = uninstall(args.root.expanduser().absolute())
        print(json.dumps(result, indent=2))
    except (OSError, ValueError, KeyError) as error:
        parser.exit(1, 'Error: {}\n'.format(error))


if __name__ == '__main__':
    main()

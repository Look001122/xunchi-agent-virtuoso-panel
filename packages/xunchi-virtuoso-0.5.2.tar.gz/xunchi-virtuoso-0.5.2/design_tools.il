; Design RPC: read-only snapshot plus explicitly user-authorized SKILL execution.
unless(boundp('xcV02TargetToken) xcV02TargetToken="")

procedure(xcV02Json(text)
 let((out char)
  if(text then
   out="\""
   for(i 1 strlen(text)
    char=substring(text i 1)
    out=strcat(out cond((char=="\"" "\\\"") (char=="\\" "\\\\")
     (char=="\n" "\\n") (char=="\r" "\\r") (char=="\t" "\\t") (t char))))
   strcat(out "\"")
   else "null")
 ))

procedure(xcV02Meta(cv)
 let((path f choices other label)
  xcV02TargetToken=sprintf(nil "%d|%d|%L|%L%s" ipcGetPid() xcU12Epoch xcU12Target cv
   if(cv then sprintf(nil "|%s/%s/%s" cv~>libName cv~>cellName cv~>viewName) else ""))
  xcV05Selection()
  choices=""
  foreach(win hiGetWindowList('window)
   other=xcU12CellView(win)
   when(other
    label=sprintf(nil "%s / %s / %s" other~>libName other~>cellName other~>viewName)
    choices=strcat(choices if(choices!="" then "," else "")
     sprintf(nil "{\"window_id\":%s,\"label\":%s}" xcV02Json(sprintf(nil "%L" win)) xcV02Json(label)))
   ))
  path=strcat(xcU12Run "/context_meta.json")
  f=outfile(strcat(path ".tmp"))
  fprintf(f "{\"protocol_version\":2,\"target_token\":%s,\"selection_token\":%s,\"valid\":%s,\"virtuoso_pid\":%d,\"target_window\":%s,\"label\":%s,\"selected_count\":%d,\"selected_objects\":%s,\"windows\":[%s]}\n"
   xcV02Json(xcV02TargetToken) xcV02Json(xcV05SelectionToken) if(cv then "true" else "false") ipcGetPid() xcV02Json(sprintf(nil "%L" xcU12Target))
   xcV02Json(if(cv then sprintf(nil "%s / %s / %s" cv~>libName cv~>cellName cv~>viewName) else "Associated window closed"))
   if(cv then length(geGetSelSet(xcU12Target)) else 0)
   xcV05ObjectsJSON(if(cv then geGetSelSet(xcU12Target) else nil) 6) choices)
  close(f) renameFile(strcat(path ".tmp") path)
 ))

procedure(xcV02Snapshot(requestId expectedToken)
 let((cv selected items n item master)
  cv=xcU12CellView(xcU12Target)
  xcV02Meta(cv)
  cond(
   (expectedToken!=xcV02TargetToken
    sprintf(nil "{\"ok\":false,\"request_id\":%s,\"error\":{\"code\":\"TARGET_CHANGED\",\"message\":\"Design target changed after this message was sent\"}}" xcV02Json(requestId)))
   (!cv
    sprintf(nil "{\"ok\":false,\"request_id\":%s,\"error\":{\"code\":\"NO_TARGET\",\"message\":\"Associated design window is closed\"}}" xcV02Json(requestId)))
   (t
    selected=geGetSelSet(xcU12Target) items="" n=0
    foreach(object selected
     when(n<100
       item=sprintf(nil "{\"object_id\":%s,\"object_type\":%s,\"name\":%s" xcV02Json(sprintf(nil "%L" object)) xcV02Json(object~>objType) xcV02Json(object~>name))
      when(object~>objType=="inst"
       master=object~>master
       when(master item=strcat(item sprintf(nil ",\"master_library\":%s,\"master_cell\":%s"
        xcV02Json(master~>libName) xcV02Json(master~>cellName)))))
      items=strcat(items if(n>0 then "," else "") item "}")
     )
     n=n+1
    )
    sprintf(nil "{\"ok\":true,\"request_id\":%s,\"source\":\"live_virtuoso_skill\",\"virtuoso_pid\":%d,\"target_window\":%s,\"target_token\":%s,\"selection_token\":%s,\"design\":{\"library\":%s,\"cell\":%s,\"view\":%s,\"access_mode\":%s},\"selected_count\":%d,\"selection_truncated\":%s,\"selected_objects\":[%s]}"
     xcV02Json(requestId) ipcGetPid() xcV02Json(sprintf(nil "%L" xcU12Target)) xcV02Json(xcV02TargetToken) xcV02Json(xcV05SelectionToken)
     xcV02Json(cv~>libName) xcV02Json(cv~>cellName) xcV02Json(cv~>viewName) xcV02Json(cv~>mode) length(selected)
     if(length(selected)>100 then "true" else "false") items)
   )
  )
 ))

procedure(xcV04ReadFile(path limit)
 let((p text line)
  text="" p=infile(path)
  when(p
   while(gets(line p) && strlen(text)<limit text=strcat(text line))
   close(p))
  if(strlen(text)>limit then substring(text 1 limit) else text)
 ))

procedure(xcV04Execute(xcExecId xcExecToken xcExecSelection xcExecUIRequest)
 let((xcExecCv xcExecPath xcExecCode xcExecPort xcExecResult xcExecOutput xcExecValue xcExecBefore xcExecAfter xcExecDiff)
  xcExecCv=xcU12CellView(xcU12Target) xcV02Meta(xcExecCv)
  cond(
   (xcExecToken!=xcV02TargetToken || !xcExecCv xcV02Snapshot(xcExecId xcExecToken))
   (!xcExecUIRequest || xcExecUIRequest!=xcV05BoundRequest
    sprintf(nil "{\"ok\":false,\"request_id\":%s,\"executed\":false,\"error\":{\"code\":\"SNAPSHOT_REQUIRED\",\"message\":\"Capture this message selection before executing design code\"}}" xcV02Json(xcExecId)))
   (!xcExecSelection || xcExecSelection!=xcV05SelectionToken
    sprintf(nil "{\"ok\":false,\"request_id\":%s,\"executed\":false,\"error\":{\"code\":\"SELECTION_CHANGED\",\"message\":\"Selection changed after sending; code was not executed. Review the selection and send again.\"}}" xcV02Json(xcExecId)))
   (t
    xcExecBefore=errset(xcV05State(xcExecCv) nil)
    xcExecBefore=when(xcExecBefore car(xcExecBefore))
    xcExecPath=strcat(xcU12Run "/skill-code-" xcExecId ".il")
    unless(isFile(xcExecPath) error("SKILL source file is missing"))
    xcExecCode=xcV04ReadFile(xcExecPath 262145)
    when(strlen(xcExecCode)>262144 error("SKILL source exceeds transport payload size"))
    hiSetCurrentWindow(xcU12Target)
    xcExecPath=strcat(xcU12Run "/skill-output-" xcExecId ".log")
    xcExecPort=outfile(xcExecPath)
    xcExecResult=let(((poport xcExecPort)) errset(evalstring(strcat("progn(\n" xcExecCode "\n)")) t))
    errset(close(xcExecPort) nil)
    xcExecOutput=xcV04ReadFile(xcExecPath 64000)
    xcExecValue=if(xcExecResult then sprintf(nil "%L" car(xcExecResult)) else "")
    when(strlen(xcExecValue)>16000 xcExecValue=substring(xcExecValue 1 16000))
    xcExecAfter=errset(when(xcU12CellView(xcU12Target)==xcExecCv xcV05State(xcExecCv)) nil)
    xcExecDiff=when(xcExecBefore && xcExecAfter && car(xcExecAfter)
     errset(xcV05Diff(xcExecBefore car(xcExecAfter)) nil))
    xcExecDiff=if(xcExecDiff then car(xcExecDiff)
     else "{\"available\":false,\"reason\":\"SNAPSHOT_OR_TARGET_UNAVAILABLE\"}")
    xcV02Meta(xcU12CellView(xcU12Target))
    sprintf(nil "{\"ok\":%s,\"executed\":true,\"request_id\":%s,\"source\":\"live_virtuoso_skill\",\"virtuoso_pid\":%d,\"target_token\":%s,\"selection_after_token\":%s,\"changes\":%s,\"value_repr\":%s,\"stdout\":%s,\"output_file\":%s,\"error\":%s}"
     if(xcExecResult then "true" else "false") xcV02Json(xcExecId) ipcGetPid() xcV02Json(xcExecToken)
     xcV02Json(xcV05SelectionToken) xcExecDiff
     xcV02Json(xcExecValue) xcV02Json(xcExecOutput) xcV02Json(xcExecPath)
     if(xcExecResult then "null" else "{\"code\":\"SKILL_EXECUTION_FAILED\",\"message\":\"SKILL raised an error; inspect stdout and CIW. Earlier expressions may already have changed the design.\"}"))
   )
  )
 ))

procedure(xcV02HandleTool()
 let((xcRpcPath xcRpcPort xcRpcId xcRpcOperation xcRpcToken xcRpcSelection xcRpcUIRequest xcRpcLine xcRpcResult xcRpcResponse xcRpcOut)
  xcRpcPath=strcat(xcU12Run "/tool.request")
  when(isFile(xcRpcPath)
   xcRpcPort=infile(xcRpcPath)
   xcRpcId=car(parseString(gets(nil xcRpcPort) "\n"))
   xcRpcOperation=car(parseString(gets(nil xcRpcPort) "\n"))
   xcRpcToken=car(parseString(gets(nil xcRpcPort) "\n"))
   xcRpcLine=gets(nil xcRpcPort)
   xcRpcSelection=when(xcRpcLine car(parseString(xcRpcLine "\n")))
   xcRpcLine=gets(nil xcRpcPort)
   xcRpcUIRequest=when(xcRpcLine car(parseString(xcRpcLine "\n")))
   close(xcRpcPort) deleteFile(xcRpcPath)
   when(xcRpcId && strlen(xcRpcId)==32 && rexMatchp("^[a-f0-9]+$" xcRpcId)
    cond(
     (xcRpcOperation=="get_design_context" xcRpcResult=errset(xcV02Snapshot(xcRpcId xcRpcToken) t))
     (xcRpcOperation=="capture_context" xcRpcResult=errset(xcV05Capture(xcRpcId xcRpcToken xcRpcSelection xcRpcUIRequest) t))
     (xcRpcOperation=="execute_skill"
      xcRpcOut=outfile(strcat(xcU12Run "/tool.executing")) fprintf(xcRpcOut "%s\n" xcRpcId) close(xcRpcOut)
      xcRpcResult=errset(xcV04Execute(xcRpcId xcRpcToken xcRpcSelection xcRpcUIRequest) t)
      deleteFile(strcat(xcU12Run "/tool.executing")))
     (t xcRpcResult=list("{\"ok\":false,\"error\":{\"code\":\"UNSUPPORTED_OPERATION\"}}"))
    )
    xcRpcResponse=if(xcRpcResult then car(xcRpcResult) else "{\"ok\":false,\"error\":{\"code\":\"SKILL_TOOL_FAILED\",\"message\":\"Tool execution failed; inspect CIW and verify design state before retrying\"}}")
    xcRpcPath=strcat(xcU12Run "/tool-response-" xcRpcId ".json")
    xcRpcOut=outfile(strcat(xcRpcPath ".tmp")) fprintf(xcRpcOut "%s\n" xcRpcResponse) close(xcRpcOut)
    renameFile(strcat(xcRpcPath ".tmp") xcRpcPath)
   )
  )
 ))
